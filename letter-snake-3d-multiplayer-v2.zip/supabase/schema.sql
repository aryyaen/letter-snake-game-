-- ============================================================================
-- Letter Snake 3D — Supabase backend (v2, hardened)
--
-- HOW TO USE
--   1. Supabase Dashboard -> Authentication -> Providers -> enable "Anonymous".
--   2. Supabase Dashboard -> SQL Editor -> paste this WHOLE file -> Run.
--      It is safe to run more than once.
--
-- DESIGN
--   * Players sign in anonymously (role "authenticated", auth.uid() is set).
--   * Lobby tables are READ-ONLY from the browser. All writes go through
--     SECURITY DEFINER functions (create_team, join_team, set_ready,
--     start_team, leave_team, touch_member) that enforce the rules on the
--     server: team size, leader-only start, one team per player, etc.
--   * Lobbies/members are only readable by members of that lobby, so nobody
--     can list or scrape other teams. Joining is done by code via join_team().
--   * Idle players are removed automatically and empty/old lobbies are purged.
-- ============================================================================


-- ---------------------------------------------------------------------------
-- 1. LEADERBOARD
-- ---------------------------------------------------------------------------
create table if not exists public.leaderboard_scores (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  username text not null check (username ~ '^[A-Za-z0-9 _-]{1,16}$'),
  player_icon text not null default '🟦' check (char_length(player_icon) <= 8),
  score integer not null check (score between 0 and 1000000),
  letters_collected integer not null default 0 check (letters_collected >= 0),
  players_eaten integer not null default 0 check (players_eaten >= 0),
  survival_seconds integer not null default 0 check (survival_seconds between 0 and 86400),
  game_mode text not null default 'classic' check (game_mode in ('classic', 'battle', 'letter', 'rush')),
  created_at timestamptz not null default now()
);

create index if not exists leaderboard_scores_rank_idx
  on public.leaderboard_scores (score desc, created_at asc);
create index if not exists leaderboard_scores_user_idx
  on public.leaderboard_scores (user_id, created_at desc);

alter table public.leaderboard_scores enable row level security;

drop policy if exists "Public can read leaderboard scores" on public.leaderboard_scores;
drop policy if exists "Players can add their own scores" on public.leaderboard_scores;

create policy "Public can read leaderboard scores"
  on public.leaderboard_scores for select using (true);
create policy "Players can add their own scores"
  on public.leaderboard_scores for insert to authenticated
  with check (auth.uid() = user_id);

-- Anti-spam: at most one score submission per player every 10 seconds.
create or replace function public.leaderboard_rate_limit()
returns trigger
language plpgsql
set search_path = public, pg_temp
as $$
begin
  if exists (
    select 1 from public.leaderboard_scores
    where user_id = new.user_id and created_at > now() - interval '10 seconds'
  ) then
    raise exception 'Too many score submissions. Please wait a few seconds.';
  end if;
  return new;
end;
$$;

drop trigger if exists leaderboard_rate_limit_trg on public.leaderboard_scores;
create trigger leaderboard_rate_limit_trg
  before insert on public.leaderboard_scores
  for each row execute function public.leaderboard_rate_limit();

-- Browser can only read and insert scores, never edit or delete them.
revoke update, delete, truncate on public.leaderboard_scores from anon, authenticated;


-- ---------------------------------------------------------------------------
-- 2. TEAM LOBBY TABLES
-- ---------------------------------------------------------------------------
create table if not exists public.team_lobbies (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code ~ '^[A-Z0-9]{6}$'),
  team_name text not null check (char_length(team_name) between 1 and 24),
  max_players integer not null default 4 check (max_players between 2 and 8),
  leader_id uuid,
  status text not null default 'open' check (status in ('open', 'started', 'closed')),
  created_at timestamptz not null default now(),
  started_at timestamptz
);
alter table public.team_lobbies add column if not exists started_at timestamptz;

create table if not exists public.team_members (
  id uuid primary key default gen_random_uuid(),
  lobby_id uuid not null references public.team_lobbies(id) on delete cascade,
  player_id uuid not null default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  username text not null check (username ~ '^[A-Za-z0-9 _-]{1,16}$'),
  player_icon text not null default '🟦' check (char_length(player_icon) <= 8),
  ready boolean not null default false,
  is_leader boolean not null default false,
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now(),
  unique (lobby_id, player_id),
  unique (lobby_id, user_id)
);

create index if not exists team_members_lobby_idx on public.team_members (lobby_id);
create index if not exists team_members_user_idx on public.team_members (user_id);
create index if not exists team_members_last_seen_idx on public.team_members (last_seen);

-- Needed so Realtime DELETE events can be filtered by lobby_id.
alter table public.team_members replica identity full;
alter table public.team_lobbies replica identity full;

alter table public.team_lobbies enable row level security;
alter table public.team_members enable row level security;


-- ---------------------------------------------------------------------------
-- 3. ROW LEVEL SECURITY (read-only, members only)
-- ---------------------------------------------------------------------------
create or replace function public.is_lobby_member(p_lobby uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.team_members
    where lobby_id = p_lobby and user_id = auth.uid()
  );
$$;

-- Remove every old policy first (including the permissive ones from schema v1).
drop policy if exists "Public can read team lobbies" on public.team_lobbies;
drop policy if exists "Players can create team lobbies" on public.team_lobbies;
drop policy if exists "Players can update team lobbies" on public.team_lobbies;
drop policy if exists "Members can read their lobby" on public.team_lobbies;
drop policy if exists "Public can read team members" on public.team_members;
drop policy if exists "Players can join teams" on public.team_members;
drop policy if exists "Players can update own team member" on public.team_members;
drop policy if exists "Players can leave teams" on public.team_members;
drop policy if exists "Members can read their lobby members" on public.team_members;

create policy "Members can read their lobby"
  on public.team_lobbies for select to authenticated
  using (public.is_lobby_member(id));

create policy "Members can read their lobby members"
  on public.team_members for select to authenticated
  using (public.is_lobby_member(lobby_id));

-- No insert/update/delete policies exist, and direct write privileges are
-- revoked as a second layer. Writes only happen via the functions below.
revoke insert, update, delete, truncate on public.team_lobbies from anon, authenticated;
revoke insert, update, delete, truncate on public.team_members from anon, authenticated;
revoke all on public.team_lobbies from anon;
revoke all on public.team_members from anon;


-- ---------------------------------------------------------------------------
-- 4. INTERNAL HELPERS (not callable from the browser)
-- ---------------------------------------------------------------------------
create or replace function public._clean_username(p_value text)
returns text
language sql
immutable
set search_path = public, pg_temp
as $$
  select coalesce(
    nullif(left(btrim(regexp_replace(coalesce(p_value, ''), '[^A-Za-z0-9 _-]', '', 'g')), 16), ''),
    'Player'
  );
$$;

-- Remove one player from a lobby. Promotes a new leader if needed and
-- deletes the lobby when it becomes empty.
create or replace function public._remove_member(p_lobby uuid, p_user uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  was_leader boolean;
  next_member public.team_members%rowtype;
begin
  delete from public.team_members
   where lobby_id = p_lobby and user_id = p_user
  returning is_leader into was_leader;

  if not found then
    return;
  end if;

  select * into next_member
    from public.team_members
   where lobby_id = p_lobby
   order by created_at
   limit 1;

  if not found then
    delete from public.team_lobbies where id = p_lobby;
    return;
  end if;

  if was_leader then
    update public.team_members set is_leader = true, ready = true where id = next_member.id;
    update public.team_lobbies set leader_id = next_member.player_id where id = p_lobby;
  end if;
end;
$$;

-- Drop idle players (no heartbeat for 90s) from open lobbies and purge
-- empty or very old lobbies. Called automatically by create_team / join_team.
create or replace function public._cleanup_stale()
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  r record;
begin
  for r in
    select m.lobby_id, m.user_id
      from public.team_members m
      join public.team_lobbies l on l.id = m.lobby_id
     where l.status = 'open'
       and m.last_seen < now() - interval '90 seconds'
  loop
    perform public._remove_member(r.lobby_id, r.user_id);
  end loop;

  delete from public.team_lobbies l
   where not exists (select 1 from public.team_members m where m.lobby_id = l.id)
      or l.created_at < now() - interval '12 hours';
end;
$$;

revoke all on function public._clean_username(text) from public, anon, authenticated;
revoke all on function public._remove_member(uuid, uuid) from public, anon, authenticated;
revoke all on function public._cleanup_stale() from public, anon, authenticated;


-- ---------------------------------------------------------------------------
-- 5. PUBLIC API (called by the game with supabase.rpc)
--    Every function returns jsonb. Expected problems come back as
--    {"error": "...", "reason": "..."} instead of raising.
-- ---------------------------------------------------------------------------

-- Create a team. The server generates the unique 6-character code.
create or replace function public.create_team(
  p_team_name text,
  p_max_players integer,
  p_username text,
  p_icon text default '🟦'
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  uid uuid := auth.uid();
  chars constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  new_code text;
  lobby public.team_lobbies%rowtype;
  member public.team_members%rowtype;
  tries integer := 0;
  old_lobby uuid;
begin
  if uid is null then
    return jsonb_build_object('error', 'You are not signed in.', 'reason', 'not-signed-in');
  end if;

  perform public._cleanup_stale();

  -- One team per player: leave any team they were in.
  for old_lobby in select lobby_id from public.team_members where user_id = uid loop
    perform public._remove_member(old_lobby, uid);
  end loop;

  loop
    tries := tries + 1;
    new_code := '';
    for i in 1..6 loop
      new_code := new_code || substr(chars, 1 + floor(random() * length(chars))::int, 1);
    end loop;
    begin
      insert into public.team_lobbies (code, team_name, max_players, status)
      values (
        new_code,
        left(coalesce(nullif(btrim(p_team_name), ''), 'Snake Hunters'), 24),
        least(8, greatest(2, coalesce(p_max_players, 4))),
        'open'
      )
      returning * into lobby;
      exit;
    exception when unique_violation then
      if tries >= 20 then
        return jsonb_build_object('error', 'Could not generate a team code. Try again.', 'reason', 'code-collision');
      end if;
    end;
  end loop;

  insert into public.team_members (lobby_id, user_id, username, player_icon, ready, is_leader)
  values (lobby.id, uid, public._clean_username(p_username), left(coalesce(nullif(p_icon, ''), '🟦'), 8), true, true)
  returning * into member;

  update public.team_lobbies set leader_id = member.player_id where id = lobby.id
  returning * into lobby;

  return jsonb_build_object('lobby', to_jsonb(lobby), 'member', to_jsonb(member));
end;
$$;

-- Join an open team by its code.
create or replace function public.join_team(
  p_code text,
  p_username text,
  p_icon text default '🟦'
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  uid uuid := auth.uid();
  clean_code text := upper(btrim(coalesce(p_code, '')));
  lobby public.team_lobbies%rowtype;
  member public.team_members%rowtype;
  old_lobby uuid;
  member_count integer;
begin
  if uid is null then
    return jsonb_build_object('error', 'You are not signed in.', 'reason', 'not-signed-in');
  end if;
  if clean_code !~ '^[A-Z0-9]{6}$' then
    return jsonb_build_object('error', 'Enter a valid 6-character team code.', 'reason', 'bad-code');
  end if;

  perform public._cleanup_stale();

  -- Lock the lobby row so two players cannot take the last slot at once.
  select * into lobby
    from public.team_lobbies
   where code = clean_code and status = 'open'
   for update;

  if not found then
    return jsonb_build_object(
      'error', format('Team %s was not found or is no longer open. Ask the leader for the current code.', clean_code),
      'reason', 'not-found');
  end if;

  -- Already in this team? Just return the existing membership.
  select * into member from public.team_members where lobby_id = lobby.id and user_id = uid;
  if found then
    update public.team_members set last_seen = now() where id = member.id returning * into member;
    return jsonb_build_object(
      'lobby', to_jsonb(lobby),
      'member', to_jsonb(member),
      'members', (select coalesce(jsonb_agg(to_jsonb(m) order by m.created_at), '[]'::jsonb)
                    from public.team_members m where m.lobby_id = lobby.id));
  end if;

  -- One team per player: leave any other team first.
  for old_lobby in select lobby_id from public.team_members where user_id = uid loop
    perform public._remove_member(old_lobby, uid);
  end loop;

  select count(*) into member_count from public.team_members where lobby_id = lobby.id;
  if member_count >= lobby.max_players then
    return jsonb_build_object('error', 'Team is full.', 'reason', 'full');
  end if;

  insert into public.team_members (lobby_id, user_id, username, player_icon, ready, is_leader)
  values (lobby.id, uid, public._clean_username(p_username), left(coalesce(nullif(p_icon, ''), '🟦'), 8), false, false)
  returning * into member;

  return jsonb_build_object(
    'lobby', to_jsonb(lobby),
    'member', to_jsonb(member),
    'members', (select coalesce(jsonb_agg(to_jsonb(m) order by m.created_at), '[]'::jsonb)
                  from public.team_members m where m.lobby_id = lobby.id));
end;
$$;

-- Toggle the caller's READY flag.
create or replace function public.set_ready(p_lobby uuid, p_ready boolean)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    return jsonb_build_object('ok', false, 'error', 'You are not signed in.');
  end if;
  update public.team_members m
     set ready = coalesce(p_ready, false), last_seen = now()
   where m.lobby_id = p_lobby
     and m.user_id = uid
     and exists (select 1 from public.team_lobbies l where l.id = p_lobby and l.status = 'open');
  if not found then
    return jsonb_build_object('ok', false, 'error', 'You are not in an open team.');
  end if;
  return jsonb_build_object('ok', true);
end;
$$;

-- Leader-only: start the match once 2+ players are all ready.
create or replace function public.start_team(p_lobby uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  uid uuid := auth.uid();
  lobby public.team_lobbies%rowtype;
  me public.team_members%rowtype;
  total integer;
  ready_count integer;
begin
  if uid is null then
    return jsonb_build_object('error', 'You are not signed in.');
  end if;

  select * into lobby from public.team_lobbies where id = p_lobby for update;
  if not found then
    return jsonb_build_object('error', 'Team not found.');
  end if;

  select * into me from public.team_members where lobby_id = p_lobby and user_id = uid;
  if not found or not me.is_leader then
    return jsonb_build_object('error', 'Only the team leader can start.');
  end if;
  if lobby.status <> 'open' then
    return jsonb_build_object('error', 'This match has already started.');
  end if;

  select count(*), count(*) filter (where ready)
    into total, ready_count
    from public.team_members where lobby_id = p_lobby;
  if total < 2 or ready_count < total then
    return jsonb_build_object('error', 'At least two ready players are required.');
  end if;

  update public.team_lobbies
     set status = 'started', started_at = now()
   where id = p_lobby
  returning * into lobby;

  return jsonb_build_object('lobby', to_jsonb(lobby));
end;
$$;

-- Leave a team (leadership passes to the next player automatically).
create or replace function public.leave_team(p_lobby uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  uid uuid := auth.uid();
begin
  if uid is null then
    return jsonb_build_object('ok', false);
  end if;
  perform public._remove_member(p_lobby, uid);
  return jsonb_build_object('ok', true);
end;
$$;

-- Heartbeat so idle/closed browsers are eventually removed from the lobby.
create or replace function public.touch_member(p_lobby uuid)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  update public.team_members
     set last_seen = now()
   where lobby_id = p_lobby and user_id = auth.uid();
  return jsonb_build_object('ok', found);
end;
$$;

-- Only signed-in (anonymous or normal) players may call the public API.
revoke all on function public.create_team(text, integer, text, text) from public, anon;
revoke all on function public.join_team(text, text, text) from public, anon;
revoke all on function public.set_ready(uuid, boolean) from public, anon;
revoke all on function public.start_team(uuid) from public, anon;
revoke all on function public.leave_team(uuid) from public, anon;
revoke all on function public.touch_member(uuid) from public, anon;
grant execute on function public.create_team(text, integer, text, text) to authenticated;
grant execute on function public.join_team(text, text, text) to authenticated;
grant execute on function public.set_ready(uuid, boolean) to authenticated;
grant execute on function public.start_team(uuid) to authenticated;
grant execute on function public.leave_team(uuid) to authenticated;
grant execute on function public.touch_member(uuid) to authenticated;

-- The browser needs SELECT (Realtime + reading members); nothing more.
grant select on public.team_lobbies to authenticated;
grant select on public.team_members to authenticated;
grant select, insert on public.leaderboard_scores to authenticated;
grant select on public.leaderboard_scores to anon;


-- ---------------------------------------------------------------------------
-- 6. REALTIME
-- ---------------------------------------------------------------------------
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'team_lobbies'
  ) then
    alter publication supabase_realtime add table public.team_lobbies;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'team_members'
  ) then
    alter publication supabase_realtime add table public.team_members;
  end if;
end $$;

-- Ask the API layer to pick up the new functions immediately.
notify pgrst, 'reload schema';

# 🎮 Letter Snake 3D

[![Three.js](https://img.shields.io/badge/Three.js-r128-black?logo=three.js)](https://threejs.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Mobile%20%7C%20Desktop%20%7C%20Mac-blue.svg)]()

> A polished, fast-paced **3D multiplayer-ready Snake game** built with **Three.js & WebGL**, designed to run smoothly on smartphones (iPhone / Android) and desktop/Mac browsers.

---

## 🌟 Game Overview

**Letter Snake 3D** is a modern 3D evolution of the classic Snake game. Instead of standard dots, players navigate a rich 3D arena collecting floating letters, numbers, and rare gems to grow their snake, hunt rival opponents, and dominate the leaderboard!

### ✨ Key Features

- 🐍 **Realistic 3D Snake Physics:** Smooth procedural slithering, natural body deformation, animated eyes & tongue, dynamic scale bumps, and trail effects.
- 💥 **Cinematic "Eat Player" Mechanic:** When eating an opponent, their player icon visibly enters your snake's mouth and travels through the body segments as a glowing energy wave before converting into mass and score!
- 🌍 **Living 3D World:** Terrain with height deformation, day/night dynamic lighting & sky shader, rippling water, mountains, foliage, and ambient environmental particles.
- 🤖 **Intelligent AI Bots:** 5 distinct AI personalities (*Explorer, Hunter, Survivor, Aggressive, and Boss Snakes*) making real-time tactical decisions.
- 🎯 **Multiple Game Modes:**
  - **Classic:** Traditional survival and growth.
  - **Battle Royale:** Fight to be the last snake standing in an intense arena.
  - **Letter Hunt:** Spell targeted words (e.g. *CODE*, *SNAKE*) for massive score multipliers.
  - **Number Rush:** Race to collect highest-value numerical points.
- ⚡ **Special Events:** Golden Letters, Number Storms, Speed Zones, Double Value, and Mega Bosses.
- 📱 **Cross-Platform Controls:**
  - **Desktop:** WASD / Arrow keys, Mouse steer, Spacebar Boost, Scroll zoom, 'C' for Cinematic camera.
  - **Mobile:** Virtual joystick, swipe steering, on-screen boost button, and multi-touch camera orbit.
- 🎵 **Procedural Audio Engine:** Interactive Web Audio API sound effects and ambient atmospheric soundtrack.

---

## 🚀 How to Play Locally

1. **Clone the repository:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/letter-snake-3d.git
   cd letter-snake-3d
```

## 🗄️ Set up the real Supabase leaderboard

1. Create a project at [Supabase](https://supabase.com/dashboard), then enable **Authentication → Providers → Anonymous sign-ins**.
2. Open **SQL Editor**, paste and run [`supabase/schema.sql`](supabase/schema.sql).
3. In **Project Settings → API**, copy the Project URL and public anon/publishable key into [`js/supabase-config.js`](js/supabase-config.js). Do not use a `service_role` key in this file.
4. Upload this folder to the same place that currently hosts `aryanhere.com`.

The game will now save finished games and show the top 20 shared scores. Until configured, it continues working locally and displays a clear setup message in the leaderboard.

### Important score-integrity note

Anonymous authentication stops visitors from writing as another player, but a browser-only game cannot prove that a score is genuine: a determined player can alter client-side JavaScript. For a competitive ranking, submit game events to a server/Edge Function and validate them there.

2. **Serve with any local web server:**
   ```bash
   # Python 3
   python3 -m http.server 8000
   
   # Or using Node.js npx
   npx serve .
   ```

3. **Open in browser:**
   Navigate to `http://localhost:8000`

---

## 🌐 Deploy to GitHub Pages (For your Instagram Link)

1. Create a new repository on GitHub named `letter-snake-3d`.
2. Push this folder to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Letter Snake 3D"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/letter-snake-3d.git
   git push -u origin main
   ```
3. Go to **Settings** > **Pages** in your GitHub repository.
4. Under **Branch**, select `main` and `/ (root)`, then click **Save**.
5. Your game will be live at:
   `https://YOUR_USERNAME.github.io/letter-snake-3d/`

---

## 🛠️ Built With

- **[Three.js](https://threejs.org/)** (3D Rendering & WebGL Engine)
- **Vanilla JavaScript (ES6+)** (Modular game architecture)
- **Web Audio API** (Procedural audio & sound effects)
- **HTML5 & CSS3** (Responsive touch UI / HUD / Minimap)

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

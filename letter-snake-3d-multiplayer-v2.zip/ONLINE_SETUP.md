# Online multiplayer setup (Supabase backend v2)

The game is a static website. Online teams need a reachable Supabase project.
The browser uses only the **Project URL** and the **publishable/anon key**.

## 1. Create (or restore) the Supabase project

- Go to https://supabase.com/dashboard.
- If your old project says **Paused**, click **Restore project**. Otherwise click **New project**
  (pick the region closest to your players, e.g. Mumbai `ap-south-1`) and wait until it is ready.

## 2. Enable anonymous sign-ins

**Authentication -> Sign In / Providers -> Anonymous Sign-Ins -> enable -> Save.**
(Players join without creating an account.)

## 3. Run the database script

**SQL Editor -> New query -> paste all of `supabase/schema.sql` -> Run.**
You should see "Success. No rows returned". It is safe to run again later.

This creates the leaderboard, the team lobby tables, row-level security and the server
functions the game calls: `create_team`, `join_team`, `set_ready`, `start_team`,
`leave_team`, `touch_member`. It also enables Realtime for the lobby tables.

## 4. Put the keys in the game

**Project Settings -> API** (or the "Connect" button):

- Copy **Project URL**
- Copy the **publishable** key (`sb_publishable_...`) or the legacy **anon** key

Paste both into `js/supabase-config.js`. Never use the `service_role` / secret key here.

## 5. Allow your website URL

**Authentication -> URL Configuration:** set **Site URL** to `https://aryanhere.com`
and add it under Redirect URLs.

## 6. Publish

Upload the whole folder again (all files, not only the config), then hard-refresh the site
(Cmd+Shift+R). Scripts use `?v=4` so browsers fetch the new code.

## 7. Test

1. Browser A: open the site -> Multiplayer -> Create Team -> copy the 6-character code.
2. Browser B (private window or another device): Join with that code.
3. Both should appear in the lobby. Mark both READY, then the leader presses START.

## Rules enforced by the server

- Max players 2 to 8; a full team rejects new players.
- Only the leader can start, and only when 2+ players are all ready.
- One team per player at a time; leaving passes leadership to the next player.
- Idle players (no heartbeat for 90 s) are removed; empty or 12-hour-old lobbies are deleted.
- Lobbies are only visible to their own members. Nobody can list or edit other teams.
- Leaderboard: one score submission per player per 10 seconds; scores cannot be edited or deleted from the browser.

## Troubleshooting

- **"Supabase connection/authentication failed: Load failed / Failed to fetch"**: the project is
  paused or deleted, the URL is wrong, or the network blocks supabase.co. Restore the project and
  check the URL in `js/supabase-config.js`.
- **"Anonymous sign-ins are disabled"**: repeat step 2.
- **"Could not find the function public.create_team"**: run `supabase/schema.sql` (step 3), then
  wait about a minute for the API cache to refresh.

/* ============================================
   particles.js — Particle system for effects
   ============================================ */

class ParticleSystem {
  constructor(scene) {
    this.scene = scene;
    this.pools = [];
    this.activeParticles = [];
    this.captureStreams = [];
    this.maxParticles = 260;
    this.sharedSphere = new THREE.SphereGeometry(0.5, 6, 4);
    this.sharedCube = new THREE.BoxGeometry(1, 1, 1);
    this.materialCache = new Map();
  }

  _material(color, opacity = 1) {
    const key = `${color}:${opacity}`;
    if (!this.materialCache.has(key)) {
      this.materialCache.set(key, new THREE.MeshBasicMaterial({ color, transparent: true, opacity }));
    }
    return this.materialCache.get(key).clone();
  }

  // Create a burst of particles at position
  burst(position, options = {}) {
    const {
      count = 12,
      color = 0x22c55e,
      size = 0.3,
      speed = 4,
      life = 1.0,
      gravity = -3,
      spread = 1,
      shape = 'sphere',
    } = options;

    for (let i = 0; i < count && this.activeParticles.length < this.maxParticles; i++) {
      const geo = shape === 'cube'
        ? this.sharedCube
        : this.sharedSphere;
      const mat = this._material(color);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.scale.setScalar(shape === 'cube' ? size : size);
      mesh.position.copy(position);

      // Random velocity
      const angle = Math.random() * Math.PI * 2;
      const elevation = (Math.random() - 0.5) * Math.PI;
      const spd = speed * (0.5 + Math.random() * 0.5);
      const vel = new THREE.Vector3(
        Math.cos(angle) * Math.cos(elevation) * spd * spread,
        Math.sin(elevation) * spd + speed * 0.5,
        Math.sin(angle) * Math.cos(elevation) * spd * spread,
      );

      this.scene.add(mesh);
      this.activeParticles.push({
        mesh,
        vel,
        life,
        maxLife: life,
        gravity,
        rot: new THREE.Vector3(
          (Math.random() - 0.5) * 10,
          (Math.random() - 0.5) * 10,
          (Math.random() - 0.5) * 10,
        ),
      });
    }
  }

  // Trail particle at position (smaller, simpler)
  trail(position, color = 0x22c55e, size = 0.15) {
    if (Math.random() > 0.4) return; // Throttle
    if (this.activeParticles.length >= this.maxParticles) return;
    const geo = this.sharedSphere;
    const mat = this._material(color, 0.8);
    const mesh = new THREE.Mesh(geo, mat);
    mesh.scale.setScalar(size * 2);
    mesh.position.copy(position);
    mesh.position.y += Utils.rand(-0.2, 0.2);
    this.scene.add(mesh);
    this.activeParticles.push({
      mesh,
      vel: new THREE.Vector3(
        Utils.rand(-0.5, 0.5),
        Utils.rand(0.5, 1.5),
        Utils.rand(-0.5, 0.5),
      ),
      life: 0.6,
      maxLife: 0.6,
      gravity: -2,
      rot: new THREE.Vector3(0, 0, 0),
    });
  }

  // Create a floating "+VALUE" text sprite
  floatingText(position, text, color = '#22c55e') {
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 128;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, 256, 128);
    ctx.font = 'bold 56px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    // Glow
    ctx.shadowColor = color;
    ctx.shadowBlur = 20;
    ctx.fillStyle = color;
    ctx.fillText(text, 128, 64);

    const texture = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: false,
    });
    const sprite = new THREE.Sprite(mat);
    sprite.scale.set(4, 2, 1);
    sprite.position.copy(position);
    sprite.position.y += 2;
    this.scene.add(sprite);

    this.activeParticles.push({
      mesh: sprite,
      vel: new THREE.Vector3(0, 2, 0),
      life: 2.0,
      maxLife: 2.0,
      gravity: 0,
      rot: new THREE.Vector3(0, 0, 0),
      isSprite: true,
    });
  }

  // Energy stream from point A to point B (capture effect)
  createCaptureStream(fromPos, toPos, color = 0xf59e0b) {
    const streamParticles = [];
    const count = 20;
    for (let i = 0; i < count; i++) {
      const geo = new THREE.SphereGeometry(0.15, 4, 4);
      const mat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 0,
      });
      const mesh = new THREE.Mesh(geo, mat);
      this.scene.add(mesh);
      streamParticles.push({
        mesh,
        t: i / count,
        speed: 0.6 + Math.random() * 0.4,
        offset: new THREE.Vector3(
          Utils.rand(-0.3, 0.3),
          Utils.rand(-0.3, 0.3),
          Utils.rand(-0.3, 0.3),
        ),
      });
    }
    this.captureStreams.push({
      particles: streamParticles,
      from: fromPos.clone(),
      to: toPos.clone(),
      life: 2.5,
      maxLife: 2.5,
      color,
    });
  }

  // Ring burst (for level-up / big events)
  ringBurst(position, color = 0xf59e0b, radius = 3) {
    const count = 24;
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const geo = new THREE.SphereGeometry(0.2, 4, 4);
      const mat = new THREE.MeshBasicMaterial({ color, transparent: true });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(position);
      this.scene.add(mesh);
      this.activeParticles.push({
        mesh,
        vel: new THREE.Vector3(
          Math.cos(angle) * 8,
          2,
          Math.sin(angle) * 8,
        ),
        life: 1.0,
        maxLife: 1.0,
        gravity: -4,
        rot: new THREE.Vector3(0, 0, 0),
      });
    }
  }

  // Snow/sparkle ambient
  ambientSparkle(bounds = 100) {
    if (Math.random() > 0.02) return;
    const pos = new THREE.Vector3(
      Utils.rand(-bounds, bounds),
      Utils.rand(1, 20),
      Utils.rand(-bounds, bounds),
    );
    this.trail(pos, 0xffffff, 0.1);
  }

  update(dt) {
    // Update regular particles
    for (let i = this.activeParticles.length - 1; i >= 0; i--) {
      const p = this.activeParticles[i];
      p.life -= dt;
      const progress = 1 - p.life / p.maxLife;
      const t = Utils.easeOutCubic(progress);

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        p.mesh.material?.dispose();
        this.activeParticles.splice(i, 1);
        continue;
      }

      // Move
      p.vel.y += p.gravity * dt;
      p.mesh.position.x += p.vel.x * dt;
      p.mesh.position.y += p.vel.y * dt;
      p.mesh.position.z += p.vel.z * dt;

      // Rotate
      if (!p.isSprite) {
        p.mesh.rotation.x += p.rot.x * dt;
        p.mesh.rotation.y += p.rot.y * dt;
        p.mesh.rotation.z += p.rot.z * dt;
      }

      // Fade out
      if (p.isSprite) {
        p.mesh.material.opacity = progress < 0.8 ? 1 : (1 - (progress - 0.8) / 0.2);
      } else {
        p.mesh.material.opacity = 1 - t;
        // Scale down
        const s = 1 - t * 0.5;
        p.mesh.scale.set(s, s, s);
      }
    }

    // Update capture streams
    for (let i = this.captureStreams.length - 1; i >= 0; i--) {
      const stream = this.captureStreams[i];
      stream.life -= dt;

      if (stream.life <= 0) {
        stream.particles.forEach(p => {
          this.scene.remove(p.mesh);
          p.mesh.material?.dispose();
        });
        this.captureStreams.splice(i, 1);
        continue;
      }

      const timeRatio = 1 - stream.life / stream.maxLife;

      stream.particles.forEach(p => {
        p.t = (p.t + dt * p.speed * 0.4) % 1;

        // Position along the path (bezier-like curve)
        const t = p.t;
        const mid = new THREE.Vector3().lerpVectors(stream.from, stream.to, 0.5);
        mid.y += 3; // Arc upward

        // Quadratic bezier
        const pos = new THREE.Vector3();
        pos.x = (1 - t) * (1 - t) * stream.from.x + 2 * (1 - t) * t * mid.x + t * t * stream.to.x;
        pos.y = (1 - t) * (1 - t) * stream.from.y + 2 * (1 - t) * t * mid.y + t * t * stream.to.y;
        pos.z = (1 - t) * (1 - t) * stream.from.z + 2 * (1 - t) * t * mid.z + t * t * stream.to.z;

        pos.add(p.offset);
        p.mesh.position.copy(pos);

        // Fade based on stream age
        const streamFade = stream.life > 0.5 ? 1 : stream.life / 0.5;
        p.mesh.material.opacity = (1 - Math.abs(p.t - 0.5) * 2) * 0.8 * streamFade;
      });
    }
  }

  dispose() {
    this.activeParticles.forEach(p => {
      this.scene.remove(p.mesh);
      p.mesh.geometry?.dispose();
      p.mesh.material?.dispose();
    });
    this.activeParticles = [];
    this.captureStreams.forEach(s => {
      s.particles.forEach(p => {
        this.scene.remove(p.mesh);
        p.mesh.geometry?.dispose();
        p.mesh.material?.dispose();
      });
    });
    this.captureStreams = [];
    this.sharedSphere.dispose();
    this.sharedCube.dispose();
    this.materialCache.forEach(material => material.dispose());
    this.materialCache.clear();
  }
}

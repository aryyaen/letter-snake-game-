/* ============================================
   utils.js — Shared utility functions
   ============================================ */

const Utils = {
  lerp(a, b, t) { return a + (b - a) * t; },
  clamp(v, min, max) { return Math.max(min, Math.min(max, v)); },
  rand(min, max) { return min + Math.random() * (max - min); },
  randInt(min, max) { return Math.floor(Utils.rand(min, max + 1)); },
  randChoice(arr) { return arr[Math.floor(Math.random() * arr.length)]; },

  toRad(deg) { return deg * Math.PI / 180; },
  toDeg(rad) { return rad * 180 / Math.PI; },

  distance2D(a, b) {
    const dx = a.x - b.x, dz = a.z - b.z;
    return Math.sqrt(dx * dx + dz * dz);
  },

  distance3D(a, b) {
    const dx = a.x - b.x, dy = a.y - b.y, dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  },

  hexToRgb(hex) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return { r: r / 255, g: g / 255, b: b / 255 };
  },

  formatScore(n) {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return Math.floor(n).toString();
  },

  formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return m > 0 ? `${m}m ${s}s` : `${s}s`;
  },

  // Easing functions
  easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); },
  easeInOutQuad(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; },
  easeOutBack(t) {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
  },

  // Color helpers
  lerpColor(a, b, t) {
    return {
      r: Utils.lerp(a.r, b.r, t),
      g: Utils.lerp(a.g, b.g, t),
      b: Utils.lerp(a.b, b.b, t),
    };
  },

  // Save / Load
  save(key, value) {
    try { localStorage.setItem('ls3d_' + key, JSON.stringify(value)); } catch (e) {}
  },
  load(key, fallback) {
    try {
      const v = localStorage.getItem('ls3d_' + key);
      return v !== null ? JSON.parse(v) : fallback;
    } catch (e) { return fallback; }
  },

  // Mobile detect
  isMobile() {
    return /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || window.innerWidth < 600;
  },
};

// Global game state shared across modules
const GameState = {
  score: 0,
  level: 1,
  xp: 0,
  xpToNext: 100,
  multiplier: 1,
  snakeLength: 5,
  lettersCollected: [],
  playersEaten: 0,
  totalLetters: 0,
  startTime: 0,
  survivalTime: 0,
  maxLength: 5,
  mode: 'classic',
  quality: 'medium',
  username: 'Player',
  playerIcon: '🟦',
  snakeColor: '#22c55e',
  trailEffect: 'none',
  paused: false,
  gameOver: false,
  wordTarget: [],
  wordCollected: [],
  // Progression
  unlockedSkins: ['default'],
  achievements: [],
  bestScore: 0,
};

// Words for Letter Hunt mode
const WORD_LIST = ['CODE', 'SNAKE', 'PIXEL', 'BOOST', 'LEVEL', 'POWER', 'SPEED', 'GAMER', 'SCORE', 'QUEST'];

const LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const NUMBERS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 50];

// ============================================
// REAL POINT VALUES — single source of truth.
// collectibles.js reads these instead of rolling
// arbitrary random ranges, so every number shown
// in the in-game "Point Values" table is exactly
// what players actually earn.
// ============================================
const POINT_VALUES = {
  LETTER_COMMON: 5,     // green letters (most common)
  LETTER_UNCOMMON: 10,  // cyan letters
  LETTER_RARE: 15,      // purple letters (rarest tier)
  GOLDEN_LETTER: 100,   // rare golden spawn
  WORD_COMPLETE_BONUS: 500,
  SPECIALS: { '⭐': 30, '💎': 50, '🔥': 25, '⚡': 20 },
};

// Drives both the spawn logic and the displayed reference table.
const POINT_TABLE = [
  { icon: '🟢', label: 'Common Letter', points: `+${POINT_VALUES.LETTER_COMMON}` },
  { icon: '🔵', label: 'Uncommon Letter', points: `+${POINT_VALUES.LETTER_UNCOMMON}` },
  { icon: '🟣', label: 'Rare Letter', points: `+${POINT_VALUES.LETTER_RARE}` },
  { icon: '✨', label: 'Golden Letter', points: `+${POINT_VALUES.GOLDEN_LETTER}` },
  { icon: '🔢', label: 'Number Tile', points: '= its own value' },
  { icon: '⭐', label: 'Star', points: `+${POINT_VALUES.SPECIALS['⭐']}` },
  { icon: '💎', label: 'Gem', points: `+${POINT_VALUES.SPECIALS['💎']}` },
  { icon: '🔥', label: 'Fire', points: `+${POINT_VALUES.SPECIALS['🔥']}` },
  { icon: '⚡', label: 'Lightning', points: `+${POINT_VALUES.SPECIALS['⚡']}` },
  { icon: '📝', label: 'Complete the Word (Letter Hunt)', points: `+${POINT_VALUES.WORD_COMPLETE_BONUS}` },
  { icon: '🐍', label: 'Eat a Rival Snake', points: "= rival's current score" },
  { icon: '⚡×2', label: 'Double Value Event (20s)', points: '×2 on pickups' },
  { icon: '🌩️', label: 'Number Storm (15s)', points: '×2 on numbers' },
];

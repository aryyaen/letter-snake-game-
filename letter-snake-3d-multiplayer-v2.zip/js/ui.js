/* ============================================
   ui.js — All UI interactions and HUD updates
   ============================================ */

const UI = (() => {
  let eventBannerTimeout = null;
  let wordDisplay = null;
  let displayedScore = 0; // eases toward GameState.score for a smooth count-up

  // ─── SCREEN NAV ───
  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
  }

  function showMenu() {
    showScreen('main-menu');
    document.getElementById('game-canvas')?.classList.add('hidden');
    document.getElementById('hud')?.classList.add('hidden');
  }

  function showGame() {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
    document.getElementById('game-canvas')?.classList.remove('hidden');
    document.getElementById('hud')?.classList.remove('hidden');
    // Show correct controls
    if (Utils.isMobile()) {
      document.getElementById('mobile-controls')?.classList.remove('hidden');
      document.getElementById('desktop-hint')?.classList.add('hidden');
    } else {
      document.getElementById('mobile-controls')?.classList.add('hidden');
      document.getElementById('desktop-hint')?.classList.remove('hidden');
    }
  }

  // ─── LOADING ───
  function updateLoading(pct, text) {
    const bar = document.getElementById('loading-bar');
    const textEl = document.getElementById('loading-text');
    if (bar) bar.style.width = pct + '%';
    if (textEl) textEl.textContent = text;
  }

  function hideLoading() {
    const el = document.getElementById('loading-screen');
    if (el) {
      el.style.transition = 'opacity 0.5s ease';
      el.style.opacity = '0';
      setTimeout(() => el.classList.add('hidden'), 500);
    }
  }

  // ─── HUD ───
  function resetHUD() {
    displayedScore = 0;
  }

  function updateHUD(dt = 0.016) {
    const score = document.getElementById('hud-score');
    const level = document.getElementById('hud-level');
    const mult = document.getElementById('hud-multiplier');
    const username = document.getElementById('hud-username');
    const icon = document.getElementById('hud-player-icon');
    const collected = document.getElementById('hud-collected');

    // Smooth, frame-rate independent count-up rather than snapping instantly —
    // small gap snaps shut immediately so it doesn't lag behind forever.
    const diff = GameState.score - displayedScore;
    if (Math.abs(diff) < 1) {
      displayedScore = GameState.score;
    } else {
      displayedScore += diff * Math.min(1, 8 * dt);
    }

    if (score) score.textContent = Utils.formatScore(Math.round(displayedScore));
    if (level) level.textContent = GameState.level;
    if (mult) mult.textContent = GameState.multiplier;
    if (username) username.textContent = GameState.username;
    if (icon) icon.textContent = GameState.playerIcon;

    // Show recently collected
    if (collected) {
      collected.innerHTML = GameState.lettersCollected
        .slice(-6)
        .map(l => `<span class="collected-badge">${l}</span>`)
        .join('');
    }
  }

  function updateLeaderboard(snakes) {
    const list = document.getElementById('hud-leaderboard-list');
    if (!list) return;

    const sorted = [...snakes]
      .filter(s => s.alive)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    list.innerHTML = sorted.map((s, i) => `
      <div class="hud-lb-row ${s.isPlayer ? 'is-player' : ''}">
        <span class="hud-lb-row-rank">${i + 1}</span>
        <span class="hud-lb-row-name">${s.playerIcon} ${s.username}</span>
        <span class="hud-lb-row-score">${Utils.formatScore(s.score)}</span>
      </div>
    `).join('');
  }

  function updateMinimap(playerSnake, allSnakes, collectibles, arenaSize) {
    const canvas = document.getElementById('minimap-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    const scale = w / (arenaSize * 2);

    ctx.clearRect(0, 0, w, h);

    // Background
    ctx.fillStyle = 'rgba(0,20,40,0.8)';
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2, 0, Math.PI * 2);
    ctx.fill();

    // Clip to circle
    ctx.save();
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.clip();

    const toScreen = (wx, wz) => ({
      x: (wx + arenaSize) * scale,
      y: (wz + arenaSize) * scale,
    });

    // Draw collectibles
    collectibles.getItems().forEach(item => {
      const sp = toScreen(item.position.x, item.position.z);
      ctx.fillStyle = item.isGolden ? '#FFD700' : item.color || '#22c55e';
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, 1.5, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw AI snakes
    allSnakes.forEach(snake => {
      if (!snake.alive || snake.isPlayer) return;
      const sp = toScreen(snake.headPosition.x, snake.headPosition.z);
      ctx.fillStyle = snake.color;
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, 3, 0, Math.PI * 2);
      ctx.fill();
    });

    // Draw player
    if (playerSnake) {
      const sp = toScreen(playerSnake.headPosition.x, playerSnake.headPosition.z);
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, 4, 0, Math.PI * 2);
      ctx.fill();
      // Direction indicator
      const dx = playerSnake.direction.x * 6;
      const dz = playerSnake.direction.z * 6;
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(sp.x, sp.y);
      ctx.lineTo(sp.x + dx, sp.y + dz);
      ctx.stroke();
    }

    ctx.restore();

    // Border
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 1, 0, Math.PI * 2);
    ctx.stroke();
  }

  // ─── NOTIFICATIONS ───
  function showNotification(message, type = 'grow') {
    const area = document.getElementById('notification-area');
    if (!area) return;

    const el = document.createElement('div');
    el.className = `notification ${type}`;
    el.textContent = message;
    area.appendChild(el);

    setTimeout(() => {
      el.remove();
    }, 3000);
  }

  function showCaptureNotification(icon, username, value) {
    showNotification(`${icon} ${username} CAPTURED! +${Utils.formatScore(value)}`, 'capture');
    showEvent(`🔥 ${username} ELIMINATED!`);
  }

  function showEvent(text, duration = 2500) {
    const banner = document.getElementById('event-banner');
    const textEl = document.getElementById('event-text');
    if (!banner || !textEl) return;

    textEl.textContent = text;
    banner.classList.remove('hidden');

    clearTimeout(eventBannerTimeout);
    eventBannerTimeout = setTimeout(() => {
      banner.classList.add('hidden');
    }, duration);
  }

  // ─── PAUSE ───
  function togglePause() {
    GameState.paused = !GameState.paused;
    const overlay = document.getElementById('pause-overlay');
    if (overlay) {
      overlay.classList.toggle('hidden', !GameState.paused);
    }
  }

  // ─── DEATH SCREEN ───
  async function showDeathScreen() {
    const overlay = document.getElementById('death-screen');
    if (!overlay) return;

    document.getElementById('death-score').textContent = Utils.formatScore(GameState.score);
    document.getElementById('death-letters').textContent = GameState.totalLetters;
    document.getElementById('death-eaten').textContent = GameState.playersEaten;
    document.getElementById('death-time').textContent = Utils.formatTime(GameState.survivalTime);
    document.getElementById('death-length').textContent = GameState.maxLength;

    overlay.classList.remove('hidden');

    // Save best score
    if (GameState.score > GameState.bestScore) {
      GameState.bestScore = GameState.score;
      Utils.save('bestScore', GameState.bestScore);
    }

    // Save XP
    const xpGained = Math.floor(GameState.score / 10);
    GameState.xp += xpGained;
    Utils.save('xp', GameState.xp);

    // A local best score still works without Supabase; this additionally saves
    // a score to the shared leaderboard when the project is configured.
    const result = await Database.submitScore(GameState);
    if (result.saved) showNotification('🏆 Score saved to the global leaderboard!', 'special');
  }

  // ─── GLOBAL LEADERBOARD ───
  function escapeHTML(value) {
    const node = document.createElement('span');
    node.textContent = String(value);
    return node.innerHTML;
  }

  async function populateGlobalLeaderboard() {
    const list = document.getElementById('global-leaderboard');
    if (!list) return;

    list.innerHTML = '<div class="lb-row"><span class="lb-name">Loading leaderboard…</span></div>';
    const { data: players, reason } = await Database.getLeaderboard();
    if (reason === 'not-configured') {
      list.innerHTML = '<div class="lb-row"><span class="lb-name">Leaderboard is not configured yet.</span></div>';
      return;
    }
    if (reason) {
      list.innerHTML = '<div class="lb-row"><span class="lb-name">Could not load the leaderboard. Please try again.</span></div>';
      return;
    }
    if (!players.length) {
      list.innerHTML = '<div class="lb-row"><span class="lb-name">No scores yet — be the first to play!</span></div>';
      return;
    }

    list.innerHTML = players.map((p, i) => `
      <div class="lb-row ${i === 0 ? 'top-1' : i === 1 ? 'top-2' : i === 2 ? 'top-3' : ''}">
        <span class="lb-rank">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : i + 1}</span>
        <span class="lb-icon">${escapeHTML(p.player_icon)}</span>
        <span class="lb-name">${escapeHTML(p.username)}</span>
        <span class="lb-score">${Utils.formatScore(p.score)}</span>
      </div>
    `).join('');
  }

  // ─── WORD DISPLAY (Letter Hunt mode) ───
  function initWordDisplay() {
    if (GameState.mode !== 'letter') return;

    // Remove existing
    if (wordDisplay) wordDisplay.remove();

    const hud = document.getElementById('hud');
    if (!hud) return;

    wordDisplay = document.createElement('div');
    wordDisplay.className = 'word-display';
    GameState.wordTarget.forEach(letter => {
      const span = document.createElement('div');
      span.className = 'word-letter';
      span.textContent = letter;
      wordDisplay.appendChild(span);
    });
    hud.appendChild(wordDisplay);
  }

  function updateWordDisplay() {
    if (!wordDisplay) return;
    const letters = wordDisplay.querySelectorAll('.word-letter');
    letters.forEach((el, i) => {
      el.classList.toggle('collected', !!GameState.wordCollected[i]);
    });
  }

  // ─── FPS ───
  function updateFPS(fps) {
    const el = document.getElementById('hud-fps');
    if (el) el.textContent = Math.round(fps) + ' FPS';
  }

  // ─── BOOST INDICATOR ───
  function updateBoostBar(fuel, max) {
    const btn = document.getElementById('btn-boost');
    if (btn) {
      const pct = fuel / max;
      btn.style.background = `radial-gradient(circle at center, rgba(245,158,11,${pct * 0.6}) 0%, rgba(0,0,0,0.5) 100%)`;
      btn.style.borderColor = `rgba(245,158,11,${0.2 + pct * 0.6})`;
    }
  }

  // ─── POINT VALUES TABLE (real, deterministic — mirrors POINT_TABLE) ───
  function populatePointValues() {
    const list = document.getElementById('points-list');
    if (!list || list.dataset.populated) return;
    list.innerHTML = POINT_TABLE.map(row => `
      <div class="points-row">
        <span class="points-item">${row.icon} ${row.label}</span>
        <span class="points-value">${row.points}</span>
      </div>
    `).join('');
    list.dataset.populated = '1';
  }

  function showPointValues() {
    populatePointValues();
    document.getElementById('points-overlay')?.classList.remove('hidden');
  }

  function hidePointValues() {
    document.getElementById('points-overlay')?.classList.add('hidden');
  }

  // ─── SCORE "BUMP" JUICE ───
  function pulseScore() {
    const box = document.getElementById('hud-score-box');
    if (!box) return;
    box.classList.remove('score-pulse');
    void box.offsetWidth; // restart the CSS animation
    box.classList.add('score-pulse');
  }

  return {
    showScreen, showMenu, showGame,
    updateLoading, hideLoading,
    updateHUD, resetHUD, updateLeaderboard, updateMinimap,
    showNotification, showCaptureNotification, showEvent,
    togglePause, showDeathScreen,
    populateGlobalLeaderboard,
    initWordDisplay, updateWordDisplay,
    updateFPS, updateBoostBar,
    showPointValues, hidePointValues, pulseScore,
  };
})();

// ─── MENU EVENT LISTENERS ───
document.addEventListener('DOMContentLoaded', () => {
  // Customize
  const skinColors = document.getElementById('skin-colors');
  if (skinColors) {
    skinColors.addEventListener('click', e => {
      const swatch = e.target.closest('.color-swatch');
      if (!swatch) return;
      skinColors.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('selected'));
      swatch.classList.add('selected');
      GameState.snakeColor = swatch.dataset.color;
    });
  }

  const playerIcons = document.getElementById('player-icons');
  if (playerIcons) {
    playerIcons.addEventListener('click', e => {
      const swatch = e.target.closest('.icon-swatch');
      if (!swatch) return;
      playerIcons.querySelectorAll('.icon-swatch').forEach(s => s.classList.remove('selected'));
      swatch.classList.add('selected');
      GameState.playerIcon = swatch.dataset.icon;
    });
  }

  const trailEffects = document.getElementById('trail-effects');
  if (trailEffects) {
    trailEffects.addEventListener('click', e => {
      const swatch = e.target.closest('.trail-swatch');
      if (!swatch) return;
      trailEffects.querySelectorAll('.trail-swatch').forEach(s => s.classList.remove('selected'));
      swatch.classList.add('selected');
      GameState.trailEffect = swatch.dataset.trail;
    });
  }

  // Settings
  document.getElementById('setting-sfx')?.addEventListener('input', e => {
    AudioEngine.setSFXVolume(e.target.value / 100);
  });
  document.getElementById('setting-music')?.addEventListener('input', e => {
    AudioEngine.setMusicVolume(e.target.value / 100);
  });
  document.getElementById('setting-quality')?.addEventListener('change', e => {
    GameState.quality = e.target.value;
    Utils.save('quality', GameState.quality);
  });
});

/* ============================================
   camera.js — Dynamic 3rd-person camera
   ============================================ */

class GameCamera {
  constructor(camera, renderer) {
    this.camera = camera;
    this.renderer = renderer;

    // Camera settings
    this.distance = 22;
    this.targetDistance = 22;
    this.minDistance = 14;
    this.maxDistance = 60;
    this.height = 10;
    this.targetHeight = 10;

    // Angle
    this.theta = 0; // Horizontal angle
    this.phi = 0.5; // Vertical angle (radians from top)
    this.targetTheta = 0;
    this.targetPhi = 0.5;

    // Lerp speeds
    this.posLerp = 5;
    this.rotLerp = 4;

    // Current tracked position
    this.currentLookAt = new THREE.Vector3();
    this.targetLookAt = new THREE.Vector3();

    // Cinematic mode
    this.cinematicMode = false;
    this.cinematicTimer = 0;
    this.cinematicDuration = 3;

    // Screen shake (impact feedback for captures, deaths, boss spawns)
    this.shakeIntensity = 0;
    this.shakeDecay = 4.5;

    // Dynamic field of view — widens for speed/boost and "punches" on big events
    this.baseFov = camera.fov;
    this.targetFov = camera.fov;
    this.boosting = false;

    // Mouse/touch orbit
    this.isOrbiting = false;
    this.lastMouseX = 0;
    this.lastMouseY = 0;
    this.autoOrbit = true;
    this.autoOrbitSpeed = 0.15;

    this._setupMouseOrbit();
  }

  _setupMouseOrbit() {
    const renderer = this.renderer;

    renderer.domElement.addEventListener('mousedown', e => {
      this.isOrbiting = true;
      this.autoOrbit = false;
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
    });

    document.addEventListener('mouseup', () => {
      this.isOrbiting = false;
      // Re-enable auto orbit after 3 seconds
      setTimeout(() => { this.autoOrbit = true; }, 3000);
    });

    document.addEventListener('mousemove', e => {
      if (!this.isOrbiting) return;
      const dx = e.clientX - this.lastMouseX;
      const dy = e.clientY - this.lastMouseY;
      this.lastMouseX = e.clientX;
      this.lastMouseY = e.clientY;
      this.targetTheta -= dx * 0.008;
      this.targetPhi = Utils.clamp(this.targetPhi + dy * 0.005, 0.2, 1.2);
    });

    // Scroll to zoom
    renderer.domElement.addEventListener('wheel', e => {
      e.preventDefault();
      this.targetDistance = Utils.clamp(this.targetDistance + e.deltaY * 0.05, this.minDistance, this.maxDistance);
    }, { passive: false });

    // Touch orbit for mobile
    let lastTouchX = 0, lastTouchY = 0, touchOrbiting = false;
    renderer.domElement.addEventListener('touchstart', e => {
      if (e.touches.length === 2) {
        touchOrbiting = true;
        lastTouchX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
        lastTouchY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      }
    }, { passive: true });

    renderer.domElement.addEventListener('touchmove', e => {
      if (!touchOrbiting || e.touches.length !== 2) return;
      const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
      const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
      const dx = cx - lastTouchX;
      const dy = cy - lastTouchY;
      this.targetTheta -= dx * 0.006;
      this.targetPhi = Utils.clamp(this.targetPhi + dy * 0.004, 0.2, 1.2);
      lastTouchX = cx;
      lastTouchY = cy;
    }, { passive: true });

    renderer.domElement.addEventListener('touchend', () => {
      touchOrbiting = false;
    });
  }

  setTarget(snakeHead) {
    this.targetSnake = snakeHead;
  }

  triggerCinematic(targetPos, duration = 3) {
    this.cinematicMode = true;
    this.cinematicTimer = 0;
    this.cinematicDuration = duration;
    this.cinematicTarget = targetPos.clone();
    this.cinematicStartPos = this.camera.position.clone();
    this.cinematicStartLook = this.currentLookAt.clone();
  }

  // Punchy impact shake — captures, deaths, boss spawns, level-ups.
  shake(intensity = 1) {
    this.shakeIntensity = Math.max(this.shakeIntensity, intensity);
  }

  // Quick FOV kick that eases back to normal — adds a cinematic "punch"
  // to big moments without needing any extra geometry or shaders.
  punchFov(amount = 8) {
    this.targetFov = this.baseFov + amount;
    clearTimeout(this._fovResetTimer);
    this._fovResetTimer = setTimeout(() => { this.targetFov = this.boosting ? this.baseFov + 5 : this.baseFov; }, 150);
  }

  // Toggled every frame from Game so the camera can widen slightly during
  // a boost — a cheap, mobile-friendly way to sell a sense of speed.
  setBoosting(isBoosting) {
    if (this.boosting === isBoosting) return;
    this.boosting = isBoosting;
    if (this.targetFov === this.baseFov || this.targetFov === this.baseFov + 5) {
      this.targetFov = isBoosting ? this.baseFov + 5 : this.baseFov;
    }
  }

  // Camera responds to snake size
  updateForSnakeSize(snakeLength) {
    const sizeRatio = snakeLength / 8;
    this.targetDistance = Utils.clamp(
      this.minDistance + sizeRatio * 4,
      this.minDistance,
      this.maxDistance * 0.6
    );
    this.targetHeight = Utils.clamp(8 + sizeRatio * 2, 8, 20);
  }

  update(dt) {
    if (!this.targetSnake) return;

    const targetPos = this.targetSnake.position || this.targetSnake;
    this.targetLookAt.copy(targetPos);
    this.targetLookAt.y += 1;

    // Smooth look-at
    this.currentLookAt.lerp(this.targetLookAt, this.posLerp * dt);

    if (this.cinematicMode) {
      this._updateCinematic(dt);
    } else {
      this._updateNormal(dt);
    }

    // Smooth, frame-rate independent FOV lerp (dt-scaled so it feels the
    // same on a 30fps phone as on a 120fps desktop monitor).
    if (Math.abs(this.camera.fov - this.targetFov) > 0.01) {
      this.camera.fov = Utils.lerp(this.camera.fov, this.targetFov, Math.min(1, 6 * dt));
      this.camera.updateProjectionMatrix();
    }

    // Apply and decay screen shake
    if (this.shakeIntensity > 0.005) {
      const s = this.shakeIntensity;
      this.camera.position.x += (Math.random() - 0.5) * s;
      this.camera.position.y += (Math.random() - 0.5) * s * 0.6;
      this.camera.position.z += (Math.random() - 0.5) * s;
      this.shakeIntensity = Math.max(0, this.shakeIntensity - this.shakeDecay * dt);
    }

    this.camera.lookAt(this.currentLookAt);
  }

  _updateNormal(dt) {
    // Auto orbit
    if (this.autoOrbit) {
      this.targetTheta += this.autoOrbitSpeed * dt;
    }

    // Lerp angles
    this.theta = Utils.lerp(this.theta, this.targetTheta, this.rotLerp * dt);
    this.phi = Utils.lerp(this.phi, this.targetPhi, this.rotLerp * dt);
    // Pull back slightly while boosting for a stronger sense of speed
    const boostPullback = this.boosting ? 5 : 0;
    this.distance = Utils.lerp(this.distance, this.targetDistance + boostPullback, 3 * dt);
    this.height = Utils.lerp(this.height, this.targetHeight, 2 * dt);

    // Compute camera position (spherical coords around target)
    const x = this.currentLookAt.x + this.distance * Math.sin(this.theta) * Math.sin(this.phi);
    const y = this.currentLookAt.y + this.distance * Math.cos(this.phi) + this.height;
    const z = this.currentLookAt.z + this.distance * Math.cos(this.theta) * Math.sin(this.phi);

    this.camera.position.lerp(new THREE.Vector3(x, y, z), this.posLerp * dt);

    // Keep camera above ground
    this.camera.position.y = Math.max(this.camera.position.y, 2);
  }

  _updateCinematic(dt) {
    this.cinematicTimer += dt;
    const t = Math.min(this.cinematicTimer / this.cinematicDuration, 1);
    const et = Utils.easeInOutQuad(t);

    if (t >= 1) {
      this.cinematicMode = false;
      return;
    }

    // Cinematic sweep
    const angle = Math.sin(this.cinematicTimer * 0.5) * 0.5;
    const dist = this.distance * 0.6;
    const cx = this.currentLookAt.x + dist * Math.sin(this.theta + angle);
    const cy = this.currentLookAt.y + 8 + Math.sin(this.cinematicTimer) * 3;
    const cz = this.currentLookAt.z + dist * Math.cos(this.theta + angle);

    this.camera.position.lerp(new THREE.Vector3(cx, cy, cz), 3 * dt);
  }

  // Toggle camera modes
  toggleCinematic() {
    if (this.targetSnake) {
      this.triggerCinematic(this.targetSnake.position || this.targetSnake);
    }
  }
}

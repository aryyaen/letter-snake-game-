/* ============================================
   controls.js — Input handling (desktop + mobile)
   ============================================ */

class InputController {
  constructor(playerSnake, camera, gameCamera) {
    this.snake = playerSnake;
    this.camera = camera;
    this.gameCamera = gameCamera;
    this.isMobile = Utils.isMobile();

    // Keyboard state
    this.keys = {};
    // Mouse state
    this.mouseX = 0;
    this.mouseY = 0;
    this.isPointerLocked = false;

    // Joystick state
    this.joystickActive = false;
    this.joystickDx = 0;
    this.joystickDz = 0;
    this.joystickBaseEl = document.getElementById('joystick-base');
    this.joystickStickEl = document.getElementById('joystick-stick');
    this.joystickContainerEl = document.getElementById('joystick-container');

    // Swipe state
    this.swipeStartX = 0;
    this.swipeStartY = 0;
    this.swipeActive = false;

    if (!this.isMobile) {
      this._setupKeyboard();
      this._setupMouse();
    } else {
      this._setupJoystick();
      this._setupSwipe();
    }

    this._setupBoostButton();
    this._setupPause();
  }

  _setupKeyboard() {
    window.addEventListener('keydown', e => {
      this.keys[e.code] = true;
      if (e.code === 'Space') {
        e.preventDefault();
        this.snake.boosting = true;
        AudioEngine.SFX.boost();
      }
      if (e.code === 'Escape') {
        UI.togglePause();
      }
      if (e.code === 'KeyC') {
        this.gameCamera.toggleCinematic();
      }
    });

    window.addEventListener('keyup', e => {
      this.keys[e.code] = false;
      if (e.code === 'Space') {
        this.snake.boosting = false;
      }
    });
  }

  _setupMouse() {
    const canvas = document.getElementById('game-canvas');

    canvas.addEventListener('mousemove', e => {
      const rect = canvas.getBoundingClientRect();
      this.mouseX = (e.clientX - rect.left) / rect.width * 2 - 1;
      this.mouseY = -(e.clientY - rect.top) / rect.height * 2 + 1;
    });

    canvas.addEventListener('mousedown', e => {
      if (e.button === 2) {
        this.snake.boosting = true;
        AudioEngine.SFX.boost();
      }
    });

    canvas.addEventListener('mouseup', e => {
      if (e.button === 2) this.snake.boosting = false;
    });

    canvas.addEventListener('contextmenu', e => e.preventDefault());
  }

  _setupJoystick() {
    const base = this.joystickBaseEl;
    const stick = this.joystickStickEl;
    if (!base || !stick) return;

    const maxDist = 38;

    const getPos = (e) => {
      const touch = e.changedTouches ? e.changedTouches[0] : e;
      return { x: touch.clientX, y: touch.clientY };
    };

    base.addEventListener('touchstart', e => {
      e.preventDefault();
      this.joystickActive = true;
      this.joystickStartX = getPos(e).x;
      this.joystickStartY = getPos(e).y;
    }, { passive: false });

    base.addEventListener('touchmove', e => {
      e.preventDefault();
      if (!this.joystickActive) return;
      const pos = getPos(e);
      let dx = pos.x - this.joystickStartX;
      let dy = pos.y - this.joystickStartY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist > maxDist) {
        dx = (dx / dist) * maxDist;
        dy = (dy / dist) * maxDist;
      }

      stick.style.transform = `translate(${dx}px, ${dy}px)`;
      this.joystickDx = dx / maxDist;
      this.joystickDz = dy / maxDist;
    }, { passive: false });

    const endJoystick = () => {
      this.joystickActive = false;
      this.joystickDx = 0;
      this.joystickDz = 0;
      stick.style.transform = 'translate(0,0)';
    };

    base.addEventListener('touchend', endJoystick);
    base.addEventListener('touchcancel', endJoystick);
  }

  _setupSwipe() {
    const canvas = document.getElementById('game-canvas');
    canvas.addEventListener('touchstart', e => {
      if (e.touches.length !== 1) return;
      this.swipeStartX = e.touches[0].clientX;
      this.swipeStartY = e.touches[0].clientY;
      this.swipeActive = true;
    }, { passive: true });

    canvas.addEventListener('touchmove', e => {
      if (!this.swipeActive || e.touches.length !== 1) return;
      const dx = e.touches[0].clientX - this.swipeStartX;
      const dz = e.touches[0].clientY - this.swipeStartY;

      if (Math.abs(dx) > 5 || Math.abs(dz) > 5) {
        this.joystickDx = Math.max(-1, Math.min(1, dx / 100));
        this.joystickDz = Math.max(-1, Math.min(1, dz / 100));
      }
    }, { passive: true });

    canvas.addEventListener('touchend', () => {
      this.swipeActive = false;
      this.joystickDx = 0;
      this.joystickDz = 0;
    });
  }

  _setupBoostButton() {
    const btn = document.getElementById('btn-boost');
    if (!btn) return;
    btn.addEventListener('touchstart', e => {
      e.preventDefault();
      this.snake.boosting = true;
      AudioEngine.SFX.boost();
    }, { passive: false });
    btn.addEventListener('touchend', () => { this.snake.boosting = false; });
    btn.addEventListener('mousedown', () => {
      this.snake.boosting = true;
      AudioEngine.SFX.boost();
    });
    btn.addEventListener('mouseup', () => { this.snake.boosting = false; });
  }

  _setupPause() {
    const btn = document.getElementById('btn-pause-mobile');
    if (btn) btn.addEventListener('click', () => UI.togglePause());
  }

  update(dt) {
    if (GameState.paused || !this.snake.alive) return;

    if (this.isMobile) {
      this._updateMobile(dt);
    } else {
      this._updateDesktop(dt);
    }
  }

  _updateDesktop(dt) {
    const keys = this.keys;
    let inputX = 0, inputZ = 0;

    if (keys['KeyW'] || keys['ArrowUp']) inputZ = -1;
    if (keys['KeyS'] || keys['ArrowDown']) inputZ = 1;
    if (keys['KeyA'] || keys['ArrowLeft']) inputX = -1;
    if (keys['KeyD'] || keys['ArrowRight']) inputX = 1;

    // If no key input, use mouse direction
    if (inputX === 0 && inputZ === 0) {
      // Convert mouse position to world direction relative to camera
      const camForward = new THREE.Vector3();
      this.camera.getWorldDirection(camForward);
      camForward.y = 0;
      camForward.normalize();

      const camRight = new THREE.Vector3();
      camRight.crossVectors(camForward, new THREE.Vector3(0, 1, 0)).normalize();

      // Mouse influences direction subtly
      inputX = this.mouseX * 0.6;
      inputZ = -this.mouseY * 0.3;

      if (Math.abs(inputX) < 0.05 && Math.abs(inputZ) < 0.05) return;

      const dir = new THREE.Vector3()
        .addScaledVector(camRight, inputX)
        .addScaledVector(camForward, -inputZ);
      dir.y = 0;
      if (dir.length() > 0.01) {
        this.snake.targetDirection.lerp(dir.normalize(), 4 * dt);
        this.snake.targetDirection.normalize();
      }
      return;
    }

    // Key input: transform by camera forward direction
    const camForward = new THREE.Vector3();
    this.camera.getWorldDirection(camForward);
    camForward.y = 0;
    camForward.normalize();

    const camRight = new THREE.Vector3();
    camRight.crossVectors(camForward, new THREE.Vector3(0, 1, 0)).normalize();

    const inputDir = new THREE.Vector3()
      .addScaledVector(camRight, inputX)
      .addScaledVector(camForward, -inputZ);
    inputDir.y = 0;

    if (inputDir.length() > 0.01) {
      this.snake.targetDirection.lerp(inputDir.normalize(), 6 * dt);
      this.snake.targetDirection.normalize();
    }
  }

  _updateMobile(dt) {
    if (!this.joystickActive && !this.swipeActive) return;
    if (Math.abs(this.joystickDx) < 0.05 && Math.abs(this.joystickDz) < 0.05) return;

    // Transform joystick input by camera angle
    const camForward = new THREE.Vector3();
    this.camera.getWorldDirection(camForward);
    camForward.y = 0;
    camForward.normalize();

    const camRight = new THREE.Vector3();
    camRight.crossVectors(camForward, new THREE.Vector3(0, 1, 0)).normalize();

    const inputDir = new THREE.Vector3()
      .addScaledVector(camRight, this.joystickDx)
      .addScaledVector(camForward, -this.joystickDz);
    inputDir.y = 0;

    if (inputDir.length() > 0.01) {
      this.snake.targetDirection.lerp(inputDir.normalize(), 6 * dt);
      this.snake.targetDirection.normalize();
    }
  }
}

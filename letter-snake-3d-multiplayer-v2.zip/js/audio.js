/* ============================================
   audio.js — Web Audio API sound engine
   ============================================ */

const AudioEngine = (() => {
  let ctx = null;
  let masterGain = null;
  let sfxGain = null;
  let musicGain = null;
  let initialized = false;

  function init() {
    if (initialized) return;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      masterGain = ctx.createGain();
      masterGain.gain.value = 1.0;
      masterGain.connect(ctx.destination);

      sfxGain = ctx.createGain();
      sfxGain.gain.value = 0.8;
      sfxGain.connect(masterGain);

      musicGain = ctx.createGain();
      musicGain.gain.value = 0.3;
      musicGain.connect(masterGain);

      initialized = true;
      startAmbientMusic();
    } catch (e) {
      console.warn('Web Audio not supported:', e);
    }
  }

  function resume() {
    if (ctx && ctx.state === 'suspended') ctx.resume();
  }

  function playTone(freq, type = 'sine', dur = 0.15, vol = 0.3, delay = 0) {
    if (!ctx) return;
    resume();
    const t = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(sfxGain);
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t);
    gain.gain.setValueAtTime(vol, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  function playChord(freqs, type = 'sine', dur = 0.2, vol = 0.2) {
    freqs.forEach((f, i) => playTone(f, type, dur, vol, i * 0.03));
  }

  // Sound effects
  const SFX = {
    collect() {
      playTone(440, 'sine', 0.12, 0.25);
      playTone(660, 'sine', 0.1, 0.2, 0.08);
    },
    collectNumber() {
      playChord([330, 440, 550], 'triangle', 0.2, 0.2);
    },
    growSnake() {
      playTone(220, 'sawtooth', 0.1, 0.15);
      playTone(330, 'sine', 0.15, 0.2, 0.08);
      playTone(440, 'sine', 0.12, 0.15, 0.16);
    },
    boost() {
      if (!ctx) return;
      resume();
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(sfxGain);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(200, t);
      osc.frequency.exponentialRampToValueAtTime(600, t + 0.3);
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
      osc.start(t);
      osc.stop(t + 0.5);
    },
    capture() {
      if (!ctx) return;
      resume();
      const t = ctx.currentTime;
      // Rising dramatic chord
      [150, 200, 300, 450].forEach((f, i) => {
        playTone(f, 'square', 0.5, 0.15, i * 0.06);
      });
      // Victory sound
      playChord([440, 550, 660, 880], 'sine', 0.4, 0.2);
    },
    death() {
      if (!ctx) return;
      resume();
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(sfxGain);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(400, t);
      osc.frequency.exponentialRampToValueAtTime(50, t + 1.0);
      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 1.0);
      osc.start(t);
      osc.stop(t + 1.1);
    },
    levelUp() {
      [262, 330, 392, 523, 659, 784].forEach((f, i) => {
        playTone(f, 'triangle', 0.2, 0.25, i * 0.08);
      });
    },
    specialEvent() {
      playChord([220, 277, 330, 440, 554, 659], 'triangle', 0.6, 0.18);
    },
    move() {
      if (Math.random() > 0.9) {
        playTone(Utils.rand(60, 100), 'sine', 0.05, 0.03);
      }
    },
  };

  // Ambient procedural music
  function startAmbientMusic() {
    if (!ctx || !initialized) return;
    const baseFreqs = [65.4, 87.3, 98.0, 130.8];
    const interval = setInterval(() => {
      if (!ctx || ctx.state === 'closed') {
        clearInterval(interval);
        return;
      }
      const freq = Utils.randChoice(baseFreqs);
      const t = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      osc.type = 'triangle';
      osc.frequency.value = freq;
      filter.type = 'lowpass';
      filter.frequency.value = 400;
      osc.connect(filter);
      filter.connect(gainNode);
      gainNode.connect(musicGain);
      gainNode.gain.setValueAtTime(0, t);
      gainNode.gain.linearRampToValueAtTime(0.08, t + 0.5);
      gainNode.gain.linearRampToValueAtTime(0, t + 3);
      osc.start(t);
      osc.stop(t + 3.5);
    }, 2000);
  }

  function setSFXVolume(v) { if (sfxGain) sfxGain.gain.value = v; }
  function setMusicVolume(v) { if (musicGain) musicGain.gain.value = v; }

  return { init, resume, SFX, setSFXVolume, setMusicVolume };
})();

/* ============================================
   snake.js — Snake entity (player & AI base)
   ============================================ */

class Snake {
  constructor(scene, particles, options = {}) {
    this.scene = scene;
    this.particles = particles;

    // Identity
    this.id = options.id || Math.random().toString(36).slice(2);
    this.username = options.username || 'Snake';
    this.color = options.color || '#22c55e';
    this.playerIcon = options.playerIcon || '🟦';
    this.trailEffect = options.trailEffect || 'none';
    this.isPlayer = options.isPlayer || false;
    this.isAI = options.isAI || false;
    this.aiPersonality = options.aiPersonality || 'explorer';
    this.quality = options.quality || GameState.quality || 'medium';

    // Physics
    this.speed = options.speed || 12;
    this.baseSpeed = this.speed;
    this.direction = new THREE.Vector3(1, 0, 0);
    this.targetDirection = new THREE.Vector3(1, 0, 0);
    this.turnSpeed = 3.5;

    // Snake body
    this.segments = [];
    this.segmentCount = options.length || 8;
    this.segmentSpacing = 1.1;
    this.headRadius = 0.65;
    this.bodyRadius = 0.55;
    this.growing = 0;
    this.growQueue = 0;

    // Position history for body following
    this.posHistory = [];
    this.historyLength = 500;

    // State
    this.alive = true;
    this.boosting = false;
    this.boostFuel = 100;
    this.boostMax = 100;
    this.boostRecharge = 20;
    this.boostCost = 30;

    // Score / progression
    this.score = options.score || 0;
    this.totalScore = this.score;
    this.mass = this.segmentCount;

    // Animation
    this.tongueTimer = 0;
    this.tongueOut = false;
    this.tongueMesh = null;
    this.eyeLeft = null;
    this.eyeRight = null;
    this.labelSprite = null;
    this.captureEffectTimer = 0;
    this.captureGlowColor = new THREE.Color(0x22c55e);
    this.time = Math.random() * 100;

    // Trail particles colors
    this.trailColors = {
      none: parseInt(this.color.replace('#', '0x')),
      fire: 0xff4500,
      ice: 0x67e8f9,
      electric: 0xfbbf24,
      rainbow: 0xff0080,
    };

    // Build initial snake
    this._buildSnake(options.startPos || new THREE.Vector3(
      Utils.rand(-50, 50), 0, Utils.rand(-50, 50)
    ));
  }

  _buildSnake(startPos) {
    const colorHex = parseInt(this.color.replace('#', '0x'));

    // Create head
    const headGeo = new THREE.SphereGeometry(this.headRadius, 12, 10);
    const headMat = new THREE.MeshStandardMaterial({
      color: colorHex,
      roughness: 0.34,
      metalness: 0.08,
      emissive: new THREE.Color(colorHex).multiplyScalar(0.06),
    });
    const head = new THREE.Mesh(headGeo, headMat);
    head.castShadow = true;
    head.receiveShadow = false;
    head.position.copy(startPos);
    head.position.y = this.headRadius;
    this.scene.add(head);

    this.headMesh = head;

    // Eyes
    const eyeGeo = new THREE.SphereGeometry(0.15, 8, 8);
    const eyeMat = new THREE.MeshPhongMaterial({ color: 0xffffff, shininess: 150 });
    const pupilGeo = new THREE.SphereGeometry(0.08, 6, 6);
    const pupilMat = new THREE.MeshPhongMaterial({ color: 0x111111 });

    this.eyeLeft = new THREE.Group();
    const elW = new THREE.Mesh(eyeGeo, eyeMat);
    const elP = new THREE.Mesh(pupilGeo, pupilMat);
    elP.position.set(0.06, 0.04, 0.1);
    this.eyeLeft.add(elW, elP);
    this.eyeLeft.position.set(0.3, 0.2, 0.5);
    head.add(this.eyeLeft);

    this.eyeRight = new THREE.Group();
    const erW = new THREE.Mesh(eyeGeo, eyeMat);
    const erP = new THREE.Mesh(pupilGeo, pupilMat);
    erP.position.set(-0.06, 0.04, 0.1);
    this.eyeRight.add(erW, erP);
    this.eyeRight.position.set(-0.3, 0.2, 0.5);
    head.add(this.eyeRight);

    // Tongue
    const tongueGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.6, 6);
    const tongueMat = new THREE.MeshPhongMaterial({ color: 0xff2244 });
    this.tongueMesh = new THREE.Mesh(tongueGeo, tongueMat);
    this.tongueMesh.rotation.x = Math.PI / 2;
    this.tongueMesh.position.set(0, -0.1, 0.8);
    this.tongueMesh.visible = false;
    head.add(this.tongueMesh);

    // Nostrils (small dots)
    const nostrilGeo = new THREE.SphereGeometry(0.06, 4, 4);
    const nostrilMat = new THREE.MeshPhongMaterial({ color: 0x000000 });
    const nostrilL = new THREE.Mesh(nostrilGeo, nostrilMat);
    const nostrilR = new THREE.Mesh(nostrilGeo, nostrilMat);
    nostrilL.position.set(0.2, 0.05, 0.58);
    nostrilR.position.set(-0.2, 0.05, 0.58);
    head.add(nostrilL, nostrilR);

    // Head crown / scale bumps
    for (let i = 0; i < 5; i++) {
      const bumpGeo = new THREE.SphereGeometry(0.12, 5, 4);
      const bumpMat = new THREE.MeshPhongMaterial({
        color: new THREE.Color(colorHex).multiplyScalar(0.8).getHex(),
      });
      const bump = new THREE.Mesh(bumpGeo, bumpMat);
      const angle = (i / 5) * Math.PI - Math.PI / 2;
      bump.position.set(Math.sin(angle) * 0.45, 0.45, Math.cos(angle) * 0.15);
      head.add(bump);
    }

    this.segments = [head];

    // Build body segments
    for (let i = 1; i < this.segmentCount; i++) {
      this._addSegment(i);
    }

    // Initialize position history
    this.posHistory = [];
    for (let i = 0; i < this.historyLength; i++) {
      this.posHistory.push(startPos.clone());
    }

    // Create name label above head
    this._createLabel();
  }

  _addSegment(idx) {
    const t = idx / Math.max(this.segmentCount, 1);
    const radius = THREE.MathUtils.lerp(this.bodyRadius, this.bodyRadius * 0.6, t);
    const colorHex = parseInt(this.color.replace('#', '0x'));
    const segColor = new THREE.Color(colorHex).multiplyScalar(0.85 + t * 0.15);

    const geo = new THREE.SphereGeometry(radius, 10, 8);
    const mat = new THREE.MeshPhongMaterial({
      color: segColor,
      shininess: 40,
    });
    const mesh = new THREE.Mesh(geo, mat);
    // Casting every segment shadow is expensive with many AI snakes. Keep
    // silhouettes crisp on heads/front segments and let the body read via
    // the upgraded material and ambient occlusion-like shading.
    mesh.castShadow = this.isPlayer || idx < 3;
    mesh.receiveShadow = false;

    // Add scale bumps along body
    if (idx % 2 === 0) {
      const scaleGeo = new THREE.SphereGeometry(radius * 0.35, 4, 4);
      const scaleMat = new THREE.MeshPhongMaterial({
        color: new THREE.Color(colorHex).multiplyScalar(0.7),
      });
      const scaleMesh = new THREE.Mesh(scaleGeo, scaleMat);
      scaleMesh.position.set(0, radius * 0.8, 0);
      mesh.add(scaleMesh);
    }

    this.scene.add(mesh);
    this.segments.push(mesh);
  }

  _createLabel() {
    const canvas = document.createElement('canvas');
    canvas.width = 256; canvas.height = 80;
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = 'rgba(0,0,0,0.6)';
    ctx.roundRect(0, 0, 256, 80, 20);
    ctx.fill();

    ctx.font = 'bold 28px Arial';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 8;
    ctx.fillText(this.playerIcon + ' ' + this.username, 128, 32);

    ctx.font = '18px Arial';
    ctx.fillStyle = this.color;
    ctx.shadowBlur = 4;
    ctx.fillText(`⬡ ${Utils.formatScore(this.score)}`, 128, 56);

    const texture = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: false,
    });
    const sprite = new THREE.Sprite(mat);
    sprite.scale.set(6, 2, 1);
    sprite.position.copy(this.headMesh.position);
    sprite.position.y = this.headRadius * 2 + 2.5;
    this.scene.add(sprite);
    this.labelSprite = sprite;
  }

  _updateLabel() {
    if (!this.labelSprite) return;
    this.labelSprite.position.copy(this.headMesh.position);
    this.labelSprite.position.y = this.headRadius * 2 + 2.5 + Math.sin(this.time * 1.5) * 0.15;

    // Refresh score text periodically
    if (Math.floor(this.time * 10) % 20 === 0) {
      const canvas = document.createElement('canvas');
      canvas.width = 256; canvas.height = 80;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.roundRect?.(0, 0, 256, 80, 20);
      ctx.fill();
      ctx.font = 'bold 28px Arial';
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = this.color;
      ctx.shadowBlur = 8;
      ctx.fillText(this.playerIcon + ' ' + this.username, 128, 32);
      ctx.font = '18px Arial';
      ctx.fillStyle = this.color;
      ctx.fillText(`⬡ ${Utils.formatScore(this.score)}`, 128, 56);
      this.labelSprite.material.map.dispose();
      this.labelSprite.material.map = new THREE.CanvasTexture(canvas);
      this.labelSprite.material.needsUpdate = true;
    }
  }

  grow(amount = 1) {
    this.growQueue += amount;
    this.mass += amount * 0.5;
  }

  startCapture(capturedSnake) {
    // Trigger internal glow effect
    this.captureEffectTimer = 3.0;
    this.captureGlowColor = new THREE.Color(parseInt(capturedSnake.color.replace('#', '0x')));

    // Create stream particles
    const headPos = this.headMesh.position.clone();
    const tailPos = this.segments[this.segments.length - 1].position.clone();
    this.particles.createCaptureStream(headPos, tailPos, parseInt(capturedSnake.color.replace('#', '0x')));

    // Score + size — real value is always whatever the eaten snake actually
    // had, and only counts toward the HUD/leaderboard score if the player did it.
    const bonus = capturedSnake.score;
    this.score += bonus;
    if (this.isPlayer) GameState.score += bonus;
    this.grow(capturedSnake.segments.length * 2);

    // Floating text
    this.particles.floatingText(headPos, `+${Utils.formatScore(bonus)}`, '#f59e0b');

    // Ring burst
    this.particles.ringBurst(headPos, 0xf59e0b);

    AudioEngine.SFX.capture();
    return bonus;
  }

  get headPosition() { return this.headMesh.position; }

  update(dt) {
    if (!this.alive) return;
    this.time += dt;
    this._lastDt = dt;

    // Boost logic
    if (this.boosting && this.boostFuel > 0) {
      this.boostFuel = Math.max(0, this.boostFuel - this.boostCost * dt);
      if (this.boostFuel <= 0) this.boosting = false;
    } else if (!this.boosting) {
      this.boostFuel = Math.min(this.boostMax, this.boostFuel + this.boostRecharge * dt);
    }

    const currentSpeed = this.boosting ? this.speed * 1.8 : this.speed;

    // Smoothly turn toward target direction
    this.direction.lerp(this.targetDirection, this.turnSpeed * dt);
    this.direction.normalize();

    // Move head
    const move = this.direction.clone().multiplyScalar(currentSpeed * dt);
    this.headMesh.position.add(move);

    // Clamp to arena
    const a = 96;
    this.headMesh.position.x = Utils.clamp(this.headMesh.position.x, -a, a);
    this.headMesh.position.z = Utils.clamp(this.headMesh.position.z, -a, a);
    this.headMesh.position.y = this.headRadius + Math.sin(this.time * 2) * 0.08;

    // Slithering wave motion
    const slither = Math.sin(this.time * 8) * 0.3;
    const perpendicular = new THREE.Vector3(-this.direction.z, 0, this.direction.x);
    this.headMesh.position.addScaledVector(perpendicular, slither * 0.05);

    // Orient head to movement direction
    if (this.direction.length() > 0.01) {
      const lookTarget = this.headMesh.position.clone().add(this.direction);
      this.headMesh.lookAt(lookTarget);
      this.headMesh.rotateX(0); // Keep upright
    }

    // Update history
    this.posHistory.unshift(this.headMesh.position.clone());
    if (this.posHistory.length > this.historyLength) {
      this.posHistory.pop();
    }

    // Update body segments
    this._updateBodySegments();

    // Grow if needed
    if (this.growQueue > 0) {
      this._processGrowth();
    }

    // Animate tongue
    this._animateTongue(dt);

    // Capture glow effect
    if (this.captureEffectTimer > 0) {
      this.captureEffectTimer -= dt;
      this._applyCaptureGlow();
    }

    // Trail effect
    if (this.trailEffect !== 'none' && this.segments.length > 0) {
      const tailPos = this.segments[this.segments.length - 1].position;
      const trailColor = this.trailColors[this.trailEffect] || 0x22c55e;
      this.particles.trail(tailPos, trailColor, 0.12);
    }

    // Boost trail
    if (this.boosting) {
      const tailPos = this.segments[Math.floor(this.segments.length / 2)].position;
      this.particles.trail(tailPos, parseInt(this.color.replace('#', '0x')), 0.2);
    }

    // Update label
    this._updateLabel();

    // Ambient sparkle for player
    if (this.isPlayer && Math.random() < 0.01) {
      this.particles.trail(
        this.headMesh.position.clone(),
        parseInt(this.color.replace('#', '0x')),
        0.15
      );
    }
  }

  _updateBodySegments() {
    // Frame-rate independent smoothing factor: a fixed 0.25-per-frame lerp
    // looks noticeably different at 30fps (choppy, common on phones) vs
    // 120fps (near-instant snap) on the same device. This exponential-decay
    // formula converges at the same real-world speed regardless of frame
    // rate — tuned so it matches the original feel at a 60fps baseline.
    const followFactor = 1 - Math.exp(-17.26 * (this._lastDt || 0.016));

    for (let i = 1; i < this.segments.length; i++) {
      const targetHistoryIdx = Math.min(
        Math.floor(i * this.segmentSpacing * (60 / Math.max(this.speed, 5))),
        this.posHistory.length - 1
      );
      const targetPos = this.posHistory[targetHistoryIdx] || this.posHistory[this.posHistory.length - 1];

      // Smooth follow (same speed on any device/frame rate)
      this.segments[i].position.lerp(targetPos, followFactor);
      this.segments[i].position.y = (this.bodyRadius * 0.8) + Math.sin(this.time * 2 + i * 0.5) * 0.06;

      // Scale undulation (slithering)
      const wave = 1 + Math.sin(this.time * 8 - i * 0.6) * 0.06;
      const t = i / this.segments.length;
      const baseScale = 1 - t * 0.25;
      this.segments[i].scale.set(baseScale * wave, baseScale / wave, baseScale);

      // Subtle body sway
      if (i > 2) {
        const sway = Math.sin(this.time * 4 - i * 0.4) * 0.04;
        const perp = new THREE.Vector3(-this.direction.z, 0, this.direction.x);
        this.segments[i].position.addScaledVector(perp, sway);
      }

      // Orient segment
      if (i < this.segments.length - 1 && this.posHistory.length > targetHistoryIdx + 5) {
        const prevPos = this.posHistory[targetHistoryIdx - 3] || targetPos;
        if (prevPos) {
          this.segments[i].lookAt(prevPos);
        }
      }
    }
  }

  _processGrowth() {
    const newIdx = this.segments.length;
    this._addSegment(newIdx);
    const lastSeg = this.segments[this.segments.length - 2];
    if (lastSeg) {
      this.segments[this.segments.length - 1].position.copy(lastSeg.position);
    }
    this.growQueue--;
    this.segmentCount++;

    // Update speed inversely with size (big snakes are slower)
    this.speed = this.baseSpeed * Math.max(0.5, 1 - (this.segments.length - 8) * 0.008);

    if (this.isPlayer) {
      GameState.snakeLength = this.segments.length;
      GameState.maxLength = Math.max(GameState.maxLength, this.segments.length);
      AudioEngine.SFX.growSnake();
    }
  }

  _animateTongue(dt) {
    this.tongueTimer += dt;
    if (this.tongueTimer > 2) {
      this.tongueTimer = 0;
      this.tongueOut = !this.tongueOut;
      this.tongueMesh.visible = this.tongueOut;
    }
    if (this.tongueOut) {
      const flick = Math.sin(this.time * 20) * 0.1;
      this.tongueMesh.rotation.y = flick;
    }
  }

  _applyCaptureGlow() {
    const t = 1 - this.captureEffectTimer / 3.0;
    const pulse = Math.sin(t * Math.PI * 6) * 0.5 + 0.5;

    this.segments.forEach((seg, i) => {
      if (!seg.material) return;
      const baseColor = new THREE.Color(parseInt(this.color.replace('#', '0x')));
      seg.material.emissive = this.captureGlowColor.clone().multiplyScalar(pulse * 0.4 * (1 - i / this.segments.length));
      seg.material.emissiveIntensity = 1;
      seg.material.needsUpdate = true;
    });

    if (this.captureEffectTimer <= 0) {
      this.segments.forEach(seg => {
        if (seg.material) {
          seg.material.emissive = new THREE.Color(0x000000);
          seg.material.emissiveIntensity = 0;
        }
      });
    }
  }

  die() {
    this.alive = false;
    // Burst particles from every segment
    this.segments.forEach((seg, i) => {
      setTimeout(() => {
        this.particles.burst(seg.position, {
          count: 8,
          color: parseInt(this.color.replace('#', '0x')),
          speed: 5,
          life: 1.0,
        });
      }, i * 30);
    });

    AudioEngine.SFX.death();

    // Remove meshes
    setTimeout(() => this._dispose(), 1500);
  }

  _dispose() {
    this.segments.forEach(seg => {
      this.scene.remove(seg);
      seg.geometry?.dispose();
      seg.material?.dispose();
    });
    this.segments = [];
    if (this.labelSprite) {
      this.scene.remove(this.labelSprite);
      this.labelSprite.material.map?.dispose();
      this.labelSprite.material?.dispose();
    }
  }

  getCollisionRadius() {
    return this.headRadius * 1.1;
  }

  getBodySegmentPositions() {
    return this.segments.slice(3).map(s => s.position);
  }
}

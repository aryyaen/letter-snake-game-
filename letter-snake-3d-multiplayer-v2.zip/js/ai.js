/* ============================================
   ai.js — AI snake controller with personalities
   ============================================ */

class AIController {
  constructor(snake, allSnakes, collectibles, arenaSize = 96) {
    this.snake = snake;
    this.allSnakes = allSnakes;
    this.collectibles = collectibles;
    this.arenaSize = arenaSize;

    this.personality = snake.aiPersonality;
    this.thinkTimer = 0;
    this.thinkInterval = 0.2 + Math.random() * 0.3;
    this.targetPos = null;
    this.wanderAngle = Math.random() * Math.PI * 2;
    this.wanderTimer = 0;
    this.panicMode = false;
    this.panicTimer = 0;

    // AI-specific params per personality
    this.params = this._getPersonalityParams();
  }

  _getPersonalityParams() {
    switch (this.personality) {
      case 'explorer':
        return { collectRadius: 40, huntRadius: 0, fleeRadius: 20, aggression: 0.1, exploration: 0.8 };
      case 'hunter':
        return { collectRadius: 20, huntRadius: 50, fleeRadius: 10, aggression: 0.8, exploration: 0.2 };
      case 'survivor':
        return { collectRadius: 30, huntRadius: 0, fleeRadius: 40, aggression: 0.05, exploration: 0.5 };
      case 'aggressive':
        return { collectRadius: 15, huntRadius: 80, fleeRadius: 5, aggression: 0.95, exploration: 0.1 };
      case 'boss':
        return { collectRadius: 50, huntRadius: 100, fleeRadius: 0, aggression: 1.0, exploration: 0.3 };
      default:
        return { collectRadius: 30, huntRadius: 30, fleeRadius: 20, aggression: 0.5, exploration: 0.5 };
    }
  }

  think(dt) {
    this.thinkTimer += dt;
    if (this.thinkTimer < this.thinkInterval) return;
    this.thinkTimer = 0;

    const head = this.snake.headPosition;
    const snakeSize = this.snake.segments.length;
    const p = this.params;

    // Check for panic (near border)
    const nearBorder = Math.abs(head.x) > this.arenaSize * 0.85 || Math.abs(head.z) > this.arenaSize * 0.85;
    if (nearBorder) {
      this.panicMode = true;
      this.panicTimer = 2.0;
    }
    if (this.panicMode) {
      this.panicTimer -= this.thinkInterval;
      if (this.panicTimer <= 0) this.panicMode = false;
    }

    if (this.panicMode) {
      // Turn toward center
      const toCenter = new THREE.Vector3(0, 0, 0).sub(head).normalize();
      this.snake.targetDirection.copy(toCenter);
      return;
    }

    let bestTarget = null;
    let bestScore = -Infinity;

    // Evaluate nearby snakes to hunt
    if (p.huntRadius > 0) {
      this.allSnakes.forEach(other => {
        if (other === this.snake || !other.alive) return;
        const dist = Utils.distance3D(head, other.headPosition);
        if (dist > p.huntRadius) return;

        const isSmallerThanMe = other.segments.length < snakeSize * 0.9;
        const isLargerThanMe = other.segments.length > snakeSize * 1.1;

        if (isSmallerThanMe && p.aggression > 0.5) {
          const score = (1 - dist / p.huntRadius) * p.aggression * 100;
          if (score > bestScore) {
            bestScore = score;
            bestTarget = other.headPosition.clone();
          }
        }

        if (isLargerThanMe && p.fleeRadius > 0 && dist < p.fleeRadius) {
          // Flee
          const awayDir = head.clone().sub(other.headPosition).normalize();
          this.snake.targetDirection.copy(awayDir);
          return;
        }
      });
    }

    // Evaluate collectibles
    const items = this.collectibles.getItems();
    items.forEach(item => {
      if (item.collected) return;
      const dist = Utils.distance3D(head, item.position);
      if (dist > p.collectRadius) return;

      let itemScore = item.value / dist;
      if (item.isGolden) itemScore *= 3;
      if (item.isSpecial) itemScore *= 2;
      itemScore *= (1 - p.aggression * 0.5); // hunters care less about food

      if (itemScore > bestScore) {
        bestScore = itemScore;
        bestTarget = item.position.clone();
      }
    });

    // If we have a target, aim at it
    if (bestTarget) {
      const dir = bestTarget.clone().sub(head);
      dir.y = 0;
      if (dir.length() > 0.1) {
        this.snake.targetDirection.lerp(dir.normalize(), 0.5);
        this.snake.targetDirection.normalize();
      }
    } else {
      // Wander
      this.wanderTimer -= this.thinkInterval;
      if (this.wanderTimer <= 0) {
        this.wanderTimer = 0.5 + Math.random() * 1.5;
        this.wanderAngle += (Math.random() - 0.5) * Math.PI * 0.6;
      }
      const wanderDir = new THREE.Vector3(
        Math.cos(this.wanderAngle),
        0,
        Math.sin(this.wanderAngle)
      );
      this.snake.targetDirection.lerp(wanderDir, 0.3);
      this.snake.targetDirection.normalize();
    }

    // Boost logic for hunters / aggressive
    if (bestTarget && p.aggression > 0.7 && this.snake.boostFuel > 50) {
      const dist = Utils.distance3D(head, bestTarget);
      if (dist < 15) this.snake.boosting = true;
      else this.snake.boosting = false;
    }
  }

  update(dt) {
    if (!this.snake.alive) return;
    this.think(dt);
  }
}

// AI Snake factory
class AISnakeFactory {
  static personalities = ['explorer', 'hunter', 'survivor', 'aggressive'];
  static snakeColors = ['#ef4444', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316', '#84cc16'];
  static icons = ['🟥', '🟦', '🟨', '🟪', '🔶', '🟢', '🔴', '🔵'];
  static names = ['Shadow', 'Venom', 'Titan', 'Blaze', 'Storm', 'Nexus', 'Phantom', 'Cobra', 'Apex', 'Viper', 'Reaper', 'Nova'];

  static create(scene, particles, allSnakes, collectibles, options = {}) {
    const isBoss = options.boss || false;
    const idx = Math.floor(Math.random() * AISnakeFactory.snakeColors.length);

    const snake = new Snake(scene, particles, {
      id: 'ai_' + Math.random().toString(36).slice(2),
      username: isBoss ? '👑 ' + Utils.randChoice(AISnakeFactory.names) : Utils.randChoice(AISnakeFactory.names),
      color: AISnakeFactory.snakeColors[idx],
      playerIcon: AISnakeFactory.icons[idx],
      isAI: true,
      aiPersonality: isBoss ? 'boss' : Utils.randChoice(AISnakeFactory.personalities),
      length: isBoss ? 30 : Utils.randInt(6, 14),
      score: isBoss ? Utils.randInt(2000, 5000) : Utils.randInt(0, 500),
      speed: isBoss ? 8 : Utils.rand(9, 14),
    });

    const controller = new AIController(snake, allSnakes, collectibles);
    return { snake, controller };
  }
}

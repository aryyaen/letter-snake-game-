/* ============================================
   multiplayer.js — Team lobby + realtime session
   ============================================ */
const Multiplayer = (() => {
  const state = {
    lobby: null,
    member: null,
    members: [],
    channel: null,
    remoteStates: new Map(),
    onStart: null,
    heartbeat: null,
    demo: false,
    started: false,
  };
  const codeChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const $ = id => document.getElementById(id);
  const esc = value => { const el = document.createElement('span'); el.textContent = value ?? ''; return el.innerHTML; };
  const makeCode = () => Array.from({length: 6}, () => codeChars[Math.floor(Math.random() * codeChars.length)]).join('');
  const currentName = () => ( $('username-input')?.value || GameState.username || 'Player').trim().slice(0, 16) || 'Player';

  function render() {
    $('mp-team-name').textContent = state.lobby?.team_name || '—';
    $('mp-team-code').textContent = state.lobby?.code || '—';
    $('mp-team-status').textContent = state.lobby ? (state.lobby.status === 'started' ? 'MATCH STARTED' : 'LOBBY OPEN') : 'No team yet';
    $('mp-players').innerHTML = state.members.length ? state.members.map(m => `<div class="mp-player"><span>${esc(m.player_icon || '🟦')} ${esc(m.username)}</span><b>${m.is_leader ? 'LEADER · ' : ''}${m.ready ? 'READY' : 'NOT READY'}</b></div>`).join('') : '<div class="mp-empty">Create a team or join with a code.</div>';
    const mine = state.members.find(m => m.player_id === state.member?.player_id);
    $('mp-ready').disabled = !mine || state.lobby?.status === 'started';
    $('mp-ready').textContent = mine?.ready ? 'NOT READY' : 'READY';
    $('mp-start').disabled = !(mine?.is_leader && state.members.length >= 2 && state.members.every(m => m.ready)) || state.lobby?.status === 'started';
    $('mp-start-hint').textContent = mine?.is_leader ? (state.members.length < 2 ? 'Waiting for at least 2 players.' : state.members.every(m => m.ready) ? 'Everyone is ready.' : 'Waiting for all players…') : 'Only the team leader can start.';
  }
  function showMessage(text, bad = false) { const el = $('mp-message'); el.textContent = text; el.className = bad ? 'mp-message error' : 'mp-message'; }
  function showLobby() { $('mp-setup').classList.add('hidden'); $('mp-lobby').classList.remove('hidden'); render(); }
  function showSetup() { $('mp-setup').classList.remove('hidden'); $('mp-lobby').classList.add('hidden'); }

  async function refresh() {
    if (!state.lobby) return;
    const result = await Database.getTeamMembers(state.lobby.id);
    if (!result.error) { state.members = result.data || []; render(); }
  }
  async function create() {
    const name = ($('mp-create-name').value || 'Snake Hunters').trim().slice(0, 24) || 'Snake Hunters';
    const max = Math.min(8, Math.max(2, Number($('mp-max-players').value) || 4));
    if (state.lobby) reset();
    const code = makeCode();
    let result;
    try {
      result = await Database.createTeam({ code, team_name: name, max_players: max, username: currentName(), player_icon: GameState.playerIcon });
    } catch (error) {
      showMessage(`Could not create team: ${error?.message || error}`, true);
      return;
    }
    if (result.error) { showMessage(result.error, true); return; }
    state.lobby = result.lobby; state.member = result.member; state.members = [result.member]; state.demo = result.demo;
    await connect(); showLobby(); showMessage(state.demo ? 'Demo lobby created locally. Add Supabase keys for online play.' : 'Team created online — share the code with your teammates.');
  }
  async function join() {
    const code = ($('mp-join-code').value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!/^[A-Z0-9]{6}$/.test(code)) { showMessage('Enter a valid 6-character team code.', true); return; }
    if (state.lobby) reset();
    let result;
    try {
      result = await Database.joinTeam({ code, username: currentName(), player_icon: GameState.playerIcon });
    } catch (error) {
      showMessage(`Could not join team: ${error?.message || error}`, true);
      return;
    }
    if (result.error) { showMessage(result.error, true); return; }
    state.lobby = result.lobby; state.member = result.member; state.members = result.members || []; state.demo = result.demo;
    await connect(); showLobby(); showMessage(state.demo ? 'Demo lobby joined locally.' : 'You joined the online team. Set your status to READY when prepared.');
  }
  async function connect() {
    if (!state.lobby || state.demo) { render(); return; }
    state.channel = Database.subscribeTeam(state.lobby.id, async payload => {
      if (payload.event === 'member-change') await refresh();
      if (payload.event === 'match-started') startGame(payload.payload);
      if (payload.event === 'state' && payload.payload?.player_id !== state.member?.player_id) state.remoteStates.set(payload.payload.player_id, payload.payload);
    });
    state.heartbeat = setInterval(() => Database.touchTeamMember(state.lobby.id, state.member.player_id), 10000);
  }
  async function toggleReady() {
    if (!state.member) return;
    const ready = !state.members.find(m => m.player_id === state.member.player_id)?.ready;
    await Database.setTeamReady(state.lobby.id, state.member.player_id, ready); await refresh();
    if (state.demo) state.members = state.members.map(m => m.player_id === state.member.player_id ? {...m, ready} : m); render();
  }
  async function start() {
    const result = await Database.startTeam(state.lobby.id, state.member.player_id);
    if (result.error) { showMessage(result.error, true); return; }
    state.lobby.status = 'started'; render(); startGame(result.lobby);
  }
  function startGame(payload) { if (state.started) return; state.started = true; if (state.onStart) state.onStart('team', payload || state.lobby); }
  function publish(player) {
    if (!state.lobby || !state.member) return;
    const payload = { player_id: state.member.player_id, username: player.username, player_icon: player.playerIcon, color: player.color, x: player.headPosition.x, z: player.headPosition.z, dx: player.direction.x, dz: player.direction.z, boosting: player.boosting, score: player.score, length: player.segments.length, alive: player.alive, team_id: state.lobby.id };
    if (!state.demo) Database.broadcastTeam(state.channel, 'state', payload);
  }
  function getRemoteStates() { return [...state.remoteStates.values()]; }
  function reset() { if (state.heartbeat) clearInterval(state.heartbeat); if (state.channel) Database.removeChannel(state.channel); state.lobby = null; state.member = null; state.members = []; state.remoteStates.clear(); state.channel = null; state.heartbeat = null; state.started = false; showSetup(); }
  function init(onStart) {
    state.onStart = onStart;
    $('btn-multiplayer')?.addEventListener('click', () => { showSetup(); UI.showScreen('multiplayer-screen'); });
    $('mp-create')?.addEventListener('click', create); $('mp-join')?.addEventListener('click', join); $('mp-ready')?.addEventListener('click', toggleReady); $('mp-start')?.addEventListener('click', start);
    $('mp-copy')?.addEventListener('click', async () => { if (state.lobby) { await navigator.clipboard?.writeText(state.lobby.code); showMessage('Team code copied.'); } });
    $('mp-share')?.addEventListener('click', async () => { if (!state.lobby) return; const url = `${location.origin}${location.pathname}?team=${state.lobby.code}`; if (navigator.share) await navigator.share({title:'Letter Snake 3D team', text:`Join my team! Code: ${state.lobby.code}`, url}); else { await navigator.clipboard?.writeText(url); showMessage('Invite link copied.'); } });
    $('mp-leave')?.addEventListener('click', async () => { if (state.lobby && state.member) await Database.leaveTeam(state.lobby.id, state.member.player_id); reset(); UI.showScreen('main-menu'); });
    $('mp-back')?.addEventListener('click', () => { reset(); UI.showScreen('main-menu'); });
    const invite = new URLSearchParams(location.search).get('team'); if (invite) { showSetup(); UI.showScreen('multiplayer-screen'); $('mp-join-code').value = invite.toUpperCase(); }
  }
  return { init, publish, getRemoteStates, reset, get lobby() { return state.lobby; }, get member() { return state.member; }, get members() { return state.members; } };
})();
window.Multiplayer = Multiplayer;

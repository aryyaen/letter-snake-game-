/*
 * Add values from Supabase Dashboard → Project Settings → API.
 * Use ONLY the Project URL and the public anon/publishable key here.
 * Never put a service_role or secret key in a browser file.
 */
window.SUPABASE_CONFIG = {
  url: 'https://zjmnbqbkydbzwfeemcxs.supabase.co',
  anonKey: 'sb_publishable_MCiyo_DU2ekds82lIS21WQ_2DU6TDu4',
};

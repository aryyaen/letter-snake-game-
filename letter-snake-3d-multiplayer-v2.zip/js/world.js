/* ============================================
   world.js — 3D World / Arena Builder
   ============================================ */

class WorldBuilder {
  constructor(scene, quality = 'medium') {
    this.scene = scene;
    this.quality = quality;
    this.arenaSize = 100;
    this.decorations = [];
    this.waterMesh = null;
    this.skyMesh = null;
    this.time = 0;
    this.lights = {};
    this.fogColor = new THREE.Color(0x87ceeb);
    this.dayNightCycle = true;
    this.dayTime = 0.3; // 0 = midnight, 0.5 = noon, 1 = midnight
  }

  build() {
    this._setupFog();
    this._buildSky();
    this._buildGround();
    this._buildArenaWalls();
    this._setupLighting();
    this._buildWater();
    this._buildTrees();
    this._buildRocks();
    this._buildMountains();
    this._buildGrass();
    if (this.quality !== 'low') {
      this._buildParticleAmbient();
    }
    return this;
  }

  _setupFog() {
    this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.006);
    this.scene.background = new THREE.Color(0x87ceeb);
  }

  _buildSky() {
    // Gradient sky sphere
    const skyGeo = new THREE.SphereGeometry(500, 16, 8);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      uniforms: {
        topColor: { value: new THREE.Color(0x0077ff) },
        bottomColor: { value: new THREE.Color(0x87ceeb) },
        horizon: { value: 0.4 },
        exponent: { value: 0.6 },
      },
      vertexShader: `
        varying vec3 vPosition;
        void main() {
          vPosition = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 bottomColor;
        uniform float horizon;
        uniform float exponent;
        varying vec3 vPosition;
        void main() {
          float h = normalize(vPosition + vec3(0.0, 0.0, 0.0)).y;
          gl_FragColor = vec4(mix(bottomColor, topColor, max(pow(max(h - horizon, 0.0), exponent), 0.0)), 1.0);
        }
      `,
    });
    this.skyMesh = new THREE.Mesh(skyGeo, skyMat);
    this.scene.add(this.skyMesh);
    this.skyMaterial = skyMat;
  }

  _buildGround() {
    const a = this.arenaSize;

    // Main ground - detailed terrain
    const groundGeo = new THREE.PlaneGeometry(a * 2, a * 2, 80, 80);

    // Displace vertices for subtle terrain
    const positions = groundGeo.attributes.position;
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i);
      const y = positions.getY(i);
      const distFromCenter = Math.sqrt(x * x + y * y) / (a * 1.2);

      // Simple height noise
      const nx = x * 0.05, ny = y * 0.05;
      const h = Math.sin(nx) * Math.cos(ny) * 0.8
        + Math.sin(nx * 2.1) * Math.cos(ny * 1.9) * 0.4
        + Math.sin(nx * 4.0) * Math.cos(ny * 4.2) * 0.15;
      positions.setZ(i, h * (1 - Math.min(distFromCenter, 1) * 0.5));
    }
    groundGeo.computeVertexNormals();

    // Ground material with vertex colors
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x4a7c3f,
      roughness: 0.92,
      metalness: 0.02,
    });

    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    // Dark path / dirt layer underneath
    const dirtGeo = new THREE.PlaneGeometry(a * 2.2, a * 2.2);
    const dirtMat = new THREE.MeshStandardMaterial({ color: 0x5a3d2b, roughness: 1 });
    const dirt = new THREE.Mesh(dirtGeo, dirtMat);
    dirt.rotation.x = -Math.PI / 2;
    dirt.position.y = -0.05;
    this.scene.add(dirt);

    // Arena floor pattern (grid lines)
    if (this.quality !== 'low') {
      const gridHelper = new THREE.GridHelper(a * 2, 40, 0x000000, 0x000000);
      gridHelper.material.opacity = 0.06;
      gridHelper.material.transparent = true;
      gridHelper.position.y = 0.01;
      this.scene.add(gridHelper);
    }
  }

  _buildArenaWalls() {
    const a = this.arenaSize;
    const wallHeight = 4;
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x24543f, roughness: 0.72, metalness: 0.08, transparent: true, opacity: 0.72 });
    const wallGeo = new THREE.BoxGeometry(a * 2, wallHeight, 2);

    const wallPositions = [
      { pos: [0, wallHeight / 2, a], rot: 0 },
      { pos: [0, wallHeight / 2, -a], rot: 0 },
      { pos: [a, wallHeight / 2, 0], rot: Math.PI / 2 },
      { pos: [-a, wallHeight / 2, 0], rot: Math.PI / 2 },
    ];

    wallPositions.forEach(({ pos, rot }) => {
      const wall = new THREE.Mesh(wallGeo, wallMat);
      wall.position.set(...pos);
      wall.rotation.y = rot;
      wall.receiveShadow = true;
      this.scene.add(wall);

      // Glowing border on top of wall
      const glowGeo = new THREE.BoxGeometry(a * 2, 0.3, 0.3);
      const glowMat = new THREE.MeshBasicMaterial({ color: 0x22c55e, transparent: true, opacity: 0.7 });
      const glow = new THREE.Mesh(glowGeo, glowMat);
      glow.position.set(...pos);
      glow.position.y = pos[1] + wallHeight / 2 + 0.15;
      glow.rotation.y = rot;
      this.scene.add(glow);
    });
  }

  _setupLighting() {
    // Ambient
    const ambient = new THREE.HemisphereLight(0xc7e8ff, 0x183b2b, 0.62);
    this.scene.add(ambient);
    this.lights.ambient = ambient;

    // Sun / directional
    const sun = new THREE.DirectionalLight(0xfff2d0, 2.0);
    sun.position.set(50, 80, 30);
    sun.castShadow = true;
    sun.shadow.mapSize.width = this.quality === 'ultra' ? 4096 : this.quality === 'high' ? 2048 : 1024;
    sun.shadow.mapSize.height = sun.shadow.mapSize.width;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 300;
    sun.shadow.camera.left = -120;
    sun.shadow.camera.right = 120;
    sun.shadow.camera.top = 120;
    sun.shadow.camera.bottom = -120;
    sun.shadow.bias = -0.0005;
    this.scene.add(sun);
    this.lights.sun = sun;

    // Fill light
    const fill = new THREE.DirectionalLight(0x91bfff, 0.55);
    fill.position.set(-40, 30, -50);
    this.scene.add(fill);
    this.lights.fill = fill;

    // Point lights for atmosphere
    if (this.quality !== 'low') {
      const colors = [0xff4500, 0x00aaff, 0xffaa00, 0x00ff88];
      for (let i = 0; i < 4; i++) {
        const pl = new THREE.PointLight(colors[i], 0.5, 60);
        const angle = (i / 4) * Math.PI * 2;
        pl.position.set(Math.cos(angle) * 60, 8, Math.sin(angle) * 60);
        this.scene.add(pl);
      }
    }
  }

  _buildWater() {
    const waterGeo = new THREE.PlaneGeometry(30, 20, 8, 8);
    const waterMat = new THREE.MeshPhysicalMaterial({
      color: 0x006994,
      transparent: true,
      opacity: 0.75,
      roughness: 0.14,
      metalness: 0.12,
      clearcoat: 0.8,
      clearcoatRoughness: 0.12,
      reflectivity: 0.75,
    });
    this.waterMesh = new THREE.Mesh(waterGeo, waterMat);
    this.waterMesh.rotation.x = -Math.PI / 2;
    this.waterMesh.position.set(-55, 0.1, -55);
    this.scene.add(this.waterMesh);

    // Foam rings
    const foamGeo = new THREE.RingGeometry(14, 15, 32);
    const foamMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, side: THREE.DoubleSide });
    const foam = new THREE.Mesh(foamGeo, foamMat);
    foam.rotation.x = -Math.PI / 2;
    foam.position.set(-55, 0.15, -55);
    this.scene.add(foam);
  }

  _buildTrees() {
    const count = this.quality === 'low' ? 20 : this.quality === 'medium' ? 40 : 60;
    const a = this.arenaSize;

    for (let i = 0; i < count; i++) {
      let x, z;
      // Place near edges mostly
      const edge = Math.random() < 0.7;
      if (edge) {
        const side = Math.floor(Math.random() * 4);
        x = side === 0 ? Utils.rand(-a, a) : side === 1 ? Utils.rand(-a, a) : side === 2 ? Utils.rand(-a * 0.85, -a * 0.6) : Utils.rand(a * 0.6, a * 0.85);
        z = side === 0 ? Utils.rand(a * 0.6, a * 0.85) : side === 1 ? Utils.rand(-a * 0.85, -a * 0.6) : Utils.rand(-a, a);
      } else {
        x = Utils.rand(-a * 0.8, a * 0.8);
        z = Utils.rand(-a * 0.8, a * 0.8);
      }

      this._createTree(new THREE.Vector3(x, 0, z));
    }
  }

  _createTree(pos) {
    const group = new THREE.Group();
    const height = Utils.rand(5, 12);
    const trunkR = Utils.rand(0.3, 0.6);

    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(trunkR * 0.6, trunkR, height * 0.4, 7);
    const trunkMat = new THREE.MeshLambertMaterial({ color: 0x5c3d11 });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = height * 0.2;
    trunk.castShadow = true;
    group.add(trunk);

    // Foliage layers
    const leafColors = [0x1a6b2b, 0x228b22, 0x2d9e35, 0x145a1e];
    const layers = Utils.randInt(2, 4);
    for (let l = 0; l < layers; l++) {
      const t = l / layers;
      const r = (1 - t * 0.5) * height * 0.35;
      const geo = new THREE.ConeGeometry(r, height * 0.35, 8);
      const mat = new THREE.MeshLambertMaterial({ color: Utils.randChoice(leafColors) });
      const cone = new THREE.Mesh(geo, mat);
      cone.position.y = height * 0.35 + l * height * 0.22;
      cone.castShadow = true;
      cone.receiveShadow = true;
      group.add(cone);
    }

    group.position.copy(pos);
    group.rotation.y = Math.random() * Math.PI * 2;
    group.scale.setScalar(0.7 + Math.random() * 0.6);
    this.scene.add(group);
    this.decorations.push(group);
  }

  _buildRocks() {
    const count = this.quality === 'low' ? 15 : 30;
    const a = this.arenaSize;

    for (let i = 0; i < count; i++) {
      const pos = new THREE.Vector3(Utils.rand(-a * 0.9, a * 0.9), 0, Utils.rand(-a * 0.9, a * 0.9));
      const scale = Utils.rand(0.5, 2.5);

      const geo = new THREE.DodecahedronGeometry(scale, 0);
      // Randomize vertices slightly for organic look
      const positions = geo.attributes.position;
      for (let j = 0; j < positions.count; j++) {
        positions.setX(j, positions.getX(j) * (0.8 + Math.random() * 0.4));
        positions.setY(j, positions.getY(j) * (0.8 + Math.random() * 0.4));
        positions.setZ(j, positions.getZ(j) * (0.8 + Math.random() * 0.4));
      }
      geo.computeVertexNormals();

      const mat = new THREE.MeshLambertMaterial({
        color: Utils.randChoice([0x777777, 0x888888, 0x666666, 0x999999]),
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(pos);
      mesh.position.y = scale * 0.3;
      mesh.rotation.set(Math.random() * 2, Math.random() * 6, Math.random() * 2);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);
      this.decorations.push(mesh);
    }
  }

  _buildMountains() {
    // Distant mountains on the horizon
    const count = 12;
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2;
      const dist = this.arenaSize * 1.4;
      const pos = new THREE.Vector3(
        Math.cos(angle) * dist,
        0,
        Math.sin(angle) * dist
      );
      const scale = Utils.rand(20, 40);

      const geo = new THREE.ConeGeometry(scale * 0.6, scale, 8);
      const mat = new THREE.MeshLambertMaterial({
        color: Utils.randChoice([0x4a5568, 0x6b7280, 0x374151]),
        fog: true,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(pos);
      mesh.position.y = scale * 0.4;
      mesh.rotation.y = Math.random() * Math.PI;
      mesh.castShadow = false;
      this.scene.add(mesh);
    }

    // Snow caps
    for (let i = 0; i < count; i++) {
      const angle = (i / count) * Math.PI * 2 + 0.1;
      const dist = this.arenaSize * 1.45;
      const pos = new THREE.Vector3(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
      const scale = Utils.rand(8, 16);
      const geo = new THREE.ConeGeometry(scale * 0.2, scale * 0.35, 6);
      const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(pos);
      mesh.position.y = scale * 1.1;
      this.scene.add(mesh);
    }
  }

  _buildGrass() {
    if (this.quality === 'low') return;
    const count = this.quality === 'ultra' ? 2000 : this.quality === 'high' ? 1000 : 400;
    const a = this.arenaSize * 0.9;

    // One instanced draw call instead of hundreds/thousands of individual
    // meshes. This is the largest frame-time win in the arena.
    const grassGeo = new THREE.PlaneGeometry(0.16, 0.9);
    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x38a169,
      side: THREE.DoubleSide,
      transparent: true,
      roughness: 0.9,
    });
    const grass = new THREE.InstancedMesh(grassGeo, grassMat, count);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < count; i++) {
      const x = Utils.rand(-a, a);
      const z = Utils.rand(-a, a);
      dummy.position.set(x, Utils.rand(0.35, 0.55), z);
      dummy.rotation.set((Math.random() - 0.5) * 0.3, Math.random() * Math.PI, 0);
      dummy.scale.setScalar(0.65 + Math.random() * 0.7);
      dummy.updateMatrix();
      grass.setMatrixAt(i, dummy.matrix);
    }
    grass.instanceMatrix.needsUpdate = true;
    grass.castShadow = false;
    grass.receiveShadow = true;
    this.scene.add(grass);
  }

  _buildParticleAmbient() {
    // Floating ambient particles (dust, fireflies)
    // Handled by the particle system during update
  }

  update(dt) {
    this.time += dt;

    // Animate water
    if (this.waterMesh) {
      this.waterMesh.position.y = 0.1 + Math.sin(this.time * 0.5) * 0.05;
      const verts = this.waterMesh.geometry.attributes.position;
      for (let i = 0; i < verts.count; i++) {
        const x = verts.getX(i);
        const z = verts.getY(i);
        verts.setZ(i, Math.sin(x * 0.3 + this.time) * 0.2 + Math.cos(z * 0.2 + this.time * 0.7) * 0.15);
      }
      verts.needsUpdate = true;
      this.waterMesh.geometry.computeVertexNormals();
    }

    // Day/night cycle
    if (this.dayNightCycle && this.lights.sun) {
      this.dayTime = (this.dayTime + dt * 0.002) % 1;
      const angle = this.dayTime * Math.PI * 2;
      this.lights.sun.position.set(
        Math.cos(angle) * 80,
        Math.sin(angle) * 80,
        30
      );
      const intensity = Math.max(0, Math.sin(angle));
      this.lights.sun.intensity = intensity * 1.2;
      this.lights.ambient.intensity = 0.2 + intensity * 0.4;

      // Sky color
      if (this.skyMaterial) {
        const t = intensity;
        const topColor = new THREE.Color().lerpColors(
          new THREE.Color(0x000033),
          new THREE.Color(0x0055bb),
          t
        );
        const botColor = new THREE.Color().lerpColors(
          new THREE.Color(0x001133),
          new THREE.Color(0x87ceeb),
          t
        );
        this.skyMaterial.uniforms.topColor.value.copy(topColor);
        this.skyMaterial.uniforms.bottomColor.value.copy(botColor);
        this.scene.background = botColor.clone();
        this.scene.fog.color.copy(botColor);
      }
    }
  }
}

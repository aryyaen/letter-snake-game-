/* ============================================
   game.js — Main game engine & loop
   ============================================ */

class Game {
  constructor() {
    this.renderer = null;
    this.scene = null;
    this.camera = null;

    this.world = null;
    this.particles = null;
    this.collectibles = null;
    this.gameCamera = null;
    this.inputController = null;

    this.playerSnake = null;
    this.aiSnakes = [];
    this.allSnakes = [];
    this.teamSnakes = [];

    this.lastTime = 0;
    this.frameCount = 0;
    this.fpsAccum = 0;
    this.fps = 60;
    this.running = false;
    this.hudTimer = 0;

    this.bossSpawnTimer = 0;
    this.bossSpawnInterval = 90; // seconds
    this.hasBoss = false;

    this.scoreMultiplierTimer = 0;
    this.energyZoneActive = false;
    this.energyZoneTimer = 0;

    this._loadSettings();
  }

  _loadSettings() {
    GameState.username = Utils.load('username', 'Player');
    GameState.playerIcon = Utils.load('playerIcon', '🟦');
    GameState.snakeColor = Utils.load('snakeColor', '#22c55e');
    GameState.trailEffect = Utils.load('trailEffect', 'none');
    // Smooth-by-default: phones start on a lighter preset so the extra
    // camera/particle juice doesn't cost frame rate on lower-end hardware,
    // while desktops get the fuller cinematic look out of the box.
    GameState.quality = Utils.load('quality', Utils.isMobile() ? 'medium' : 'high');
    GameState.bestScore = Utils.load('bestScore', 0);
    GameState.xp = Utils.load('xp', 0);

    // Apply to UI
    const unameInput = document.getElementById('username-input');
    if (unameInput) unameInput.value = GameState.username;
  }

  _saveSettings() {
    Utils.save('username', GameState.username);
    Utils.save('playerIcon', GameState.playerIcon);
    Utils.save('snakeColor', GameState.snakeColor);
    Utils.save('trailEffect', GameState.trailEffect);
    Utils.save('quality', GameState.quality);
  }

  async init() {
    UI.updateLoading(10, 'Initializing renderer...');
    await this._sleep(50);

    this._initRenderer();

    UI.updateLoading(25, 'Building world...');
    await this._sleep(50);

    this._initScene();

    UI.updateLoading(45, 'Populating arena...');
    await this._sleep(50);

    this._initCollectibles();

    UI.updateLoading(60, 'Summoning snakes...');
    await this._sleep(50);

    UI.updateLoading(80, 'Calibrating physics...');
    await this._sleep(50);

    this._initResize();

    UI.updateLoading(100, 'Ready!');
    await this._sleep(400);

    UI.hideLoading();

    setTimeout(() => {
      UI.showMenu();
      this._setupMenuListeners();
    }, 600);
  }

  _sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  _initRenderer() {
    const canvas = document.getElementById('game-canvas');

    const contextAttribs = {
      antialias: GameState.quality !== 'low',
      alpha: false,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
    };

    this.renderer = new THREE.WebGLRenderer({ canvas, ...contextAttribs });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(
      window.devicePixelRatio,
      GameState.quality === 'ultra' ? 2 : GameState.quality === 'high' ? 1.5 : 1
    ));
    this.renderer.shadowMap.enabled = GameState.quality !== 'low';
    this.renderer.shadowMap.type = GameState.quality === 'ultra'
      ? THREE.PCFSoftShadowMap
      : THREE.BasicShadowMap;
    this.renderer.outputEncoding = THREE.sRGBEncoding || 3001;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = GameState.quality === 'ultra' ? 1.08 : 1.0;
    // These are supported by r128 and make the brighter materials read with
    // more depth without adding a post-processing pass.
    this.renderer.physicallyCorrectLights = true;
    this.renderer.sortObjects = true;
  }

  _initScene() {
    this.scene = new THREE.Scene();

    // Camera
    this.camera = new THREE.PerspectiveCamera(
      65,
      window.innerWidth / window.innerHeight,
      0.5,
      600
    );
    this.camera.position.set(0, 30, 40);

    // World
    this.world = new WorldBuilder(this.scene, GameState.quality);
    this.world.build();

    // Particles
    this.particles = new ParticleSystem(this.scene);

    // Game camera
    this.gameCamera = new GameCamera(this.camera, this.renderer);
  }

  _initCollectibles() {
    this.collectibles = new CollectibleManager(this.scene, this.particles);
    this.collectibles.spawnBatch(40);
  }

  _initSnakes() {
    const aiCount = GameState.mode === 'battle' ? 15 : 8;
    this.aiSnakes = [];
    this.allSnakes = [];

    // Player snake
    this.playerSnake = new Snake(this.scene, this.particles, {
      username: GameState.username,
      color: GameState.snakeColor,
      playerIcon: GameState.playerIcon,
      trailEffect: GameState.trailEffect,
      isPlayer: true,
      length: 8,
      startPos: new THREE.Vector3(0, 0, 0),
    });
    this.allSnakes.push(this.playerSnake);

    // AI snakes
    for (let i = 0; i < aiCount; i++) {
      const { snake, controller } = AISnakeFactory.create(
        this.scene,
        this.particles,
        this.allSnakes,
        this.collectibles
      );
      this.aiSnakes.push({ snake, controller });
      this.allSnakes.push(snake);
    }

    this.teamSnakes = [];
    if (GameState.mode === 'team') {
      (Multiplayer.members || []).filter(m => m.player_id !== Multiplayer.member?.player_id).forEach((member, index) => {
        const teammate = new Snake(this.scene, this.particles, {
          id: member.player_id, username: member.username, playerIcon: member.player_icon,
          color: ['#38bdf8', '#a78bfa', '#f472b6', '#facc15'][index % 4], length: 8,
          startPos: new THREE.Vector3(index * 5 - 8, 0, -8),
        });
        teammate.teamId = Multiplayer.lobby?.id;
        this.teamSnakes.push(teammate);
        this.allSnakes.push(teammate);
      });
    }

    // Camera target
    this.gameCamera.setTarget(this.playerSnake.headMesh);
    this.gameCamera.updateForSnakeSize(this.playerSnake.segments.length);

    // Input
    this.inputController = new InputController(
      this.playerSnake,
      this.camera,
      this.gameCamera
    );

    // Letter Hunt mode setup
    if (GameState.mode === 'letter') {
      GameState.wordTarget = Utils.randChoice(WORD_LIST).split('');
      GameState.wordCollected = new Array(GameState.wordTarget.length).fill(false);
      UI.initWordDisplay();
    }
  }

  startGame(mode = 'classic') {
    AudioEngine.init();
    AudioEngine.resume();

    // Reset state
    GameState.mode = mode;
    GameState.score = 0;
    GameState.level = 1;
    GameState.xp = 0;
    GameState.multiplier = 1;
    GameState.snakeLength = 8;
    GameState.lettersCollected = [];
    GameState.playersEaten = 0;
    GameState.totalLetters = 0;
    GameState.startTime = performance.now();
    GameState.survivalTime = 0;
    GameState.maxLength = 8;
    GameState.paused = false;
    GameState.gameOver = false;
    GameState.wordTarget = [];
    GameState.wordCollected = [];
    UI.resetHUD();

    // Cleanup old game
    this._cleanupGame();

    // Re-init snakes
    this._initSnakes();

    // Show game
    UI.showGame();
    this.running = true;

    // Start loop
    requestAnimationFrame(t => this._loop(t));
  }

  _cleanupGame() {
    // Dispose old snakes
    this.allSnakes.forEach(s => {
      if (s._dispose) s._dispose();
    });
    this.allSnakes = [];
    this.aiSnakes = [];
    this.teamSnakes = [];

    // Dispose collectibles
    if (this.collectibles) this.collectibles.dispose();
    this._initCollectibles();

    // Dispose particles
    if (this.particles) this.particles.dispose();
    this.particles = new ParticleSystem(this.scene);

    this.hasBoss = false;
    this.bossSpawnTimer = 0;
  }

  _loop(timestamp) {
    if (!this.running) return;

    const dt = Math.min((timestamp - this.lastTime) / 1000, 0.1);
    this.lastTime = timestamp;

    // FPS calculation
    this.frameCount++;
    this.fpsAccum += dt;
    if (this.fpsAccum >= 0.5) {
      this.fps = this.frameCount / this.fpsAccum;
      this.frameCount = 0;
      this.fpsAccum = 0;
      UI.updateFPS(this.fps);
    }

    if (!GameState.paused && !GameState.gameOver) {
      this._update(dt);
    }

    this._render();
    requestAnimationFrame(t => this._loop(t));
  }

  _update(dt) {
    // Survival time
    GameState.survivalTime = (performance.now() - GameState.startTime) / 1000;

    // World
    this.world.update(dt);

    // Particles
    this.particles.update(dt);

    // Collectibles
    this.collectibles.update(dt);

    // Input
    if (this.inputController) this.inputController.update(dt);

    // Player snake
    if (this.playerSnake && this.playerSnake.alive) {
      this.playerSnake.update(dt);
    }

    // AI snakes
    this.aiSnakes.forEach(({ snake, controller }) => {
      if (!snake.alive) return;
      controller.update(dt);
      snake.update(dt);
    });

    if (GameState.mode === 'team') this._updateTeamSnakes(dt);

    // Collisions
    this._checkCollisions();

    // Spawn new AI if count drops
    this._maintainAICount();

    // Boss snake
    this._updateBossTimer(dt);

    // Special events
    this._updateSpecialEvents(dt);

    // Camera
    if (this.playerSnake && this.playerSnake.alive) {
      this.gameCamera.updateForSnakeSize(this.playerSnake.segments.length);
      this.gameCamera.setBoosting(this.playerSnake.boosting);
    }
    this.gameCamera.update(dt);

    // HUD: gameplay remains real-time, while DOM-heavy leaderboard/minimap
    // work is capped at a comfortable 12.5Hz to protect render smoothness.
    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this._updateHUD(dt);
      this.hudTimer = 0.08;
    }

    // Level-up check
    this._checkLevelUp();

    // Player death check
    if (this.playerSnake && !this.playerSnake.alive && !GameState.gameOver) {
      this._onPlayerDeath();
    }
  }

  _updateTeamSnakes(dt) {
    const states = Multiplayer.getRemoteStates();
    this.teamSnakes.forEach(teammate => {
      const remote = states.find(s => s.player_id === teammate.id);
      if (!remote) return;
      teammate.alive = remote.alive !== false;
      teammate.boosting = Boolean(remote.boosting);
      teammate.score = Number(remote.score) || 0;
      teammate.direction.set(Number(remote.dx) || 1, 0, Number(remote.dz) || 0).normalize();
      teammate.headMesh.position.x = Utils.lerp(teammate.headMesh.position.x, Number(remote.x) || 0, Math.min(1, dt * 12));
      teammate.headMesh.position.z = Utils.lerp(teammate.headMesh.position.z, Number(remote.z) || 0, Math.min(1, dt * 12));
      teammate.headMesh.position.y = teammate.headRadius;
      teammate.posHistory.unshift(teammate.headMesh.position.clone());
      if (teammate.posHistory.length > teammate.historyLength) teammate.posHistory.pop();
      teammate._lastDt = dt;
      teammate._updateBodySegments();
      teammate._updateLabel();
    });
    Multiplayer.publish(this.playerSnake);
  }

  _checkCollisions() {
    const playerHead = this.playerSnake?.headPosition;
    if (!this.playerSnake?.alive) return;

    // ─── Player vs Collectibles ───
    this.collectibles.getItems().forEach(item => {
      if (item.collected) return;
      const dist = Utils.distance3D(playerHead, item.sprite.position);
      const radius = this.playerSnake.getCollisionRadius() + 1.2;
      if (dist < radius) {
        const val = this.collectibles.collect(item, this.playerSnake);
        UI.showNotification(`+${val} ${item.char}`, 'grow');
        UI.pulseScore();
        AudioEngine.SFX.collect();
      }
    });

    // ─── Player vs AI snake bodies ───
    this.aiSnakes.forEach(({ snake: ai }) => {
      if (!ai.alive) return;
      const bodySegs = ai.getBodySegmentPositions();
      bodySegs.forEach(segPos => {
        const dist = Utils.distance3D(playerHead, segPos);
        if (dist < this.playerSnake.getCollisionRadius() + ai.bodyRadius * 0.8) {
          // Player collides with AI body — player dies
          if (ai.segments.length > this.playerSnake.segments.length * 0.5) {
            this.playerSnake.die();
          }
        }
      });

      // AI head vs player body — running into the player's body is a real kill
      // too, so it should earn real credit just like a head-on capture does.
      if (this.playerSnake.segments.length > 4) {
        const playerBodySegs = this.playerSnake.getBodySegmentPositions();
        playerBodySegs.forEach(segPos => {
          if (!ai.alive) return;
          const dist = Utils.distance3D(ai.headPosition, segPos);
          if (dist < ai.getCollisionRadius() + this.playerSnake.bodyRadius * 0.8) {
            this._playerBlocksAI(ai);
          }
        });
      }

      // ─── Player head eats AI head (if player is bigger) ───
      const headDist = Utils.distance3D(playerHead, ai.headPosition);
      if (headDist < this.playerSnake.getCollisionRadius() + ai.getCollisionRadius()) {
        if (this.playerSnake.segments.length >= ai.segments.length * 0.85) {
          // Player eats AI
          this._playerEatsAI(ai);
        } else {
          // AI eats player
          this.playerSnake.die();
        }
      }
    });

    // ─── AI vs AI collisions ───
    for (let i = 0; i < this.aiSnakes.length; i++) {
      const { snake: a } = this.aiSnakes[i];
      if (!a.alive) continue;
      for (let j = i + 1; j < this.aiSnakes.length; j++) {
        const { snake: b } = this.aiSnakes[j];
        if (!b.alive) continue;
        const dist = Utils.distance3D(a.headPosition, b.headPosition);
        const combinedR = a.getCollisionRadius() + b.getCollisionRadius();
        if (dist < combinedR) {
          // The bigger snake captures the smaller one — previously these
          // calls were swapped, so the snake that was about to die got the
          // score/growth bonus instead of the actual winner.
          if (a.segments.length >= b.segments.length * 0.85) {
            a.startCapture(b);
            this._killAI(b);
          } else if (b.segments.length >= a.segments.length * 0.85) {
            b.startCapture(a);
            this._killAI(a);
          }
        }
      }
    }

    // ─── AI vs collectibles ───
    // collect() already credits the AI's own score with the real (multiplier-
    // applied) value — no need to add item.value a second time here.
    this.aiSnakes.forEach(({ snake: ai }) => {
      if (!ai.alive) return;
      this.collectibles.getItems().forEach(item => {
        if (item.collected) return;
        const dist = Utils.distance3D(ai.headPosition, item.sprite.position);
        if (dist < ai.getCollisionRadius() + 1.2) {
          this.collectibles.collect(item, ai);
        }
      });
    });
  }

  _playerEatsAI(ai) {
    // startCapture() already credits GameState.score once — do not add it again here.
    const bonus = this.playerSnake.startCapture(ai);
    GameState.playersEaten++;

    UI.showCaptureNotification(ai.playerIcon, ai.username, bonus);
    UI.pulseScore();
    this.gameCamera.triggerCinematic(ai.headPosition.clone(), 2);
    this.gameCamera.shake(1.2);
    this.gameCamera.punchFov(10);

    // Screen capture flash
    this._flashScreen(ai.color);

    // Kill the AI
    ai.alive = false;
    ai._dispose();

    // Check for level up
    this._checkLevelUp();
  }

  _playerBlocksAI(ai) {
    // The AI ran into the player's body — a real kill, so it earns the same
    // real score/growth reward as a head-on capture, just without hijacking
    // the camera (this can happen often against a crowd of AI).
    const bonus = this.playerSnake.startCapture(ai);
    GameState.playersEaten++;
    UI.showCaptureNotification(ai.playerIcon, ai.username, bonus);
    UI.pulseScore();
    this.gameCamera.shake(0.6);
    this._killAI(ai);
    this._checkLevelUp();
  }

  _killAI(ai) {
    if (!ai.alive) return;
    ai.die();

    // Scatter collectibles where it died
    const pos = ai.headPosition.clone();
    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        const offset = new THREE.Vector3(
          Utils.rand(-5, 5), 0, Utils.rand(-5, 5)
        );
        const spawnPos = pos.clone().add(offset);
        if (this.collectibles) {
          const item = this.collectibles.spawnCollectible();
          if (item) item.position.copy(spawnPos);
        }
      }, i * 200);
    }
  }

  _maintainAICount() {
    const targetCount = GameState.mode === 'battle' ? 12 : 7;
    const aliveCount = this.aiSnakes.filter(({ snake }) => snake.alive).length;

    if (aliveCount < targetCount && Math.random() < 0.005) {
      const { snake, controller } = AISnakeFactory.create(
        this.scene,
        this.particles,
        this.allSnakes,
        this.collectibles
      );
      this.aiSnakes.push({ snake, controller });
      this.allSnakes.push(snake);
    }
  }

  _updateBossTimer(dt) {
    if (this.hasBoss) return;
    this.bossSpawnTimer += dt;
    if (this.bossSpawnTimer >= this.bossSpawnInterval) {
      this.bossSpawnTimer = 0;
      this._spawnBoss();
    }
  }

  _spawnBoss() {
    this.hasBoss = true;
    const { snake, controller } = AISnakeFactory.create(
      this.scene,
      this.particles,
      this.allSnakes,
      this.collectibles,
      { boss: true }
    );
    this.aiSnakes.push({ snake, controller });
    this.allSnakes.push(snake);
    UI.showNotification('👑 MEGA SNAKE has entered the arena!', 'special');
    UI.showEvent('👑 MEGA SNAKE!', 4000);
    this.gameCamera.shake(1.5);
    AudioEngine.SFX.specialEvent();

    // Boss dies -> reset flag
    const origDie = snake.die.bind(snake);
    snake.die = () => {
      origDie();
      this.hasBoss = false;
      this.bossSpawnInterval = 120;
    };
  }

  _updateSpecialEvents(dt) {
    // Double value event
    if (this.scoreMultiplierTimer > 0) {
      this.scoreMultiplierTimer -= dt;
      if (this.scoreMultiplierTimer <= 0) {
        GameState.multiplier = 1;
        UI.showNotification('Double value ended', 'grow');
      }
    }

    // Energy zone
    if (this.energyZoneActive) {
      this.energyZoneTimer -= dt;
      if (this.playerSnake?.alive) {
        this.playerSnake.speed = this.playerSnake.baseSpeed * 1.5;
      }
      if (this.energyZoneTimer <= 0) {
        this.energyZoneActive = false;
        if (this.playerSnake?.alive) {
          this.playerSnake.speed = this.playerSnake.baseSpeed;
        }
        UI.showNotification('Energy Zone ended', 'grow');
      }
    }

    // Random special events
    if (Math.random() < 0.0003) {
      this._triggerRandomEvent();
    }
  }

  _triggerRandomEvent() {
    const events = ['double_value', 'energy_zone', 'number_storm'];
    const event = Utils.randChoice(events);

    switch (event) {
      case 'double_value':
        GameState.multiplier = 2;
        this.scoreMultiplierTimer = 20;
        UI.showNotification('⚡ DOUBLE VALUE! 20 seconds!', 'special');
        UI.showEvent('⚡ DOUBLE VALUE!');
        AudioEngine.SFX.specialEvent();
        break;

      case 'energy_zone':
        this.energyZoneActive = true;
        this.energyZoneTimer = 15;
        UI.showNotification('🌀 ENERGY ZONE! Speed boost!', 'special');
        UI.showEvent('🌀 ENERGY ZONE!');
        AudioEngine.SFX.specialEvent();
        break;

      case 'number_storm':
        this.collectibles.triggerNumberStorm();
        break;
    }
  }

  _checkLevelUp() {
    const xpThresholds = [0, 100, 250, 500, 1000, 2000, 4000, 8000, 15000, 30000];
    const newLevel = xpThresholds.findIndex((t, i) => {
      const next = xpThresholds[i + 1];
      return next === undefined || GameState.score < next;
    });

    const level = Math.max(1, newLevel);
    if (level > GameState.level) {
      GameState.level = level;
      UI.showNotification(`🔥 LEVEL UP! Level ${level}`, 'special');
      UI.showEvent(`🔥 LEVEL ${level}!`);
      AudioEngine.SFX.levelUp();
      this.gameCamera.punchFov(6);
      this.particles.ringBurst(
        this.playerSnake.headPosition.clone(),
        0xffd700,
        5
      );
    }
  }

  _onPlayerDeath() {
    GameState.gameOver = true;
    this.gameCamera.shake(2.2);
    this.gameCamera.triggerCinematic(
      this.playerSnake.headMesh?.position?.clone() || new THREE.Vector3(),
      4
    );

    setTimeout(() => {
      UI.showDeathScreen();
    }, 1500);
  }

  _flashScreen(colorHex) {
    const flash = document.createElement('div');
    flash.style.cssText = `
      position: fixed; inset: 0; z-index: 100;
      background: ${colorHex};
      opacity: 0.3;
      pointer-events: none;
      animation: flashFade 0.4s ease forwards;
    `;
    const style = document.createElement('style');
    style.textContent = '@keyframes flashFade { to { opacity: 0; } }';
    document.head.appendChild(style);
    document.body.appendChild(flash);
    setTimeout(() => { flash.remove(); style.remove(); }, 500);
  }

  _updateHUD(dt) {
    UI.updateHUD(dt);
    UI.updateLeaderboard(this.allSnakes);
    UI.updateMinimap(this.playerSnake, this.allSnakes, this.collectibles, 96);
    if (this.playerSnake) {
      UI.updateBoostBar(this.playerSnake.boostFuel, this.playerSnake.boostMax);
      document.getElementById('speed-vignette')?.classList.toggle('active', this.playerSnake.boosting);
    }
  }

  _render() {
    this.renderer.render(this.scene, this.camera);
  }

  _initResize() {
    window.addEventListener('resize', () => {
      const w = window.innerWidth, h = window.innerHeight;
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    });
  }

  _setupMenuListeners() {
    Multiplayer.init((mode, lobby) => this.startGame(mode, lobby));

    // Main Menu
    document.getElementById('btn-play')?.addEventListener('click', () => {
      AudioEngine.init();
      const username = document.getElementById('username-input')?.value.trim() || 'Player';
      GameState.username = username;
      Utils.save('username', username);
      UI.showScreen('mode-select');
    });

    document.getElementById('btn-customize')?.addEventListener('click', () => {
      UI.showScreen('customize-screen');
      this._startPreviewAnimation();
    });

    document.getElementById('btn-leaderboard')?.addEventListener('click', () => {
      UI.populateGlobalLeaderboard();
      UI.showScreen('leaderboard-screen');
    });

    document.getElementById('btn-points-menu')?.addEventListener('click', () => UI.showPointValues());
    document.getElementById('btn-points-pause')?.addEventListener('click', () => UI.showPointValues());
    document.getElementById('btn-points-hud')?.addEventListener('click', () => {
      if (!GameState.paused) UI.togglePause();
      UI.showPointValues();
    });
    document.getElementById('btn-close-points')?.addEventListener('click', () => UI.hidePointValues());

    document.getElementById('btn-settings')?.addEventListener('click', () => {
      const qualitySelect = document.getElementById('setting-quality');
      if (qualitySelect) qualitySelect.value = GameState.quality;
      UI.showScreen('settings-screen');
    });

    // Mode selection
    document.querySelectorAll('.mode-card').forEach(card => {
      card.addEventListener('click', () => {
        AudioEngine.init();
        const mode = card.dataset.mode;
        this.startGame(mode);
      });
    });

    document.getElementById('btn-back-menu')?.addEventListener('click', () => {
      UI.showScreen('main-menu');
    });

    // Customize
    document.getElementById('btn-save-customize')?.addEventListener('click', () => {
      this._saveSettings();
      UI.showScreen('mode-select');
    });

    document.getElementById('btn-back-customize')?.addEventListener('click', () => {
      UI.showScreen('main-menu');
    });

    // Settings back
    document.getElementById('btn-back-settings')?.addEventListener('click', () => {
      UI.showScreen('main-menu');
    });

    // Leaderboard back
    document.getElementById('btn-back-lb')?.addEventListener('click', () => {
      UI.showScreen('main-menu');
    });

    // Pause/Resume
    document.getElementById('btn-resume')?.addEventListener('click', () => {
      UI.togglePause();
    });

    document.getElementById('btn-quit-game')?.addEventListener('click', () => {
      GameState.paused = false;
      document.getElementById('pause-overlay')?.classList.add('hidden');
      this.running = false;
      UI.showMenu();
    });

    // Death screen
    document.getElementById('btn-respawn')?.addEventListener('click', () => {
      document.getElementById('death-screen')?.classList.add('hidden');
      this.startGame(GameState.mode);
    });

    document.getElementById('btn-back-death')?.addEventListener('click', () => {
      document.getElementById('death-screen')?.classList.add('hidden');
      this.running = false;
      UI.showMenu();
    });

    // Cam button
    document.getElementById('btn-cam')?.addEventListener('click', () => {
      this.gameCamera?.toggleCinematic();
    });
  }

  _startPreviewAnimation() {
    const canvas = document.getElementById('preview-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animFrame = null;
    let angle = 0;

    const draw = () => {
      ctx.clearRect(0, 0, 300, 300);
      angle += 0.02;

      // Background
      const grad = ctx.createRadialGradient(150, 150, 0, 150, 150, 150);
      grad.addColorStop(0, 'rgba(30,40,60,0.8)');
      grad.addColorStop(1, 'rgba(10,15,25,0.9)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 300, 300);

      // Draw snake preview
      const color = GameState.snakeColor || '#22c55e';
      ctx.shadowColor = color;
      ctx.shadowBlur = 12;

      // Snake body (coiled)
      const segments = 12;
      for (let i = 0; i < segments; i++) {
        const t = i / segments;
        const r = 80 - t * 20;
        const a = angle + t * Math.PI * 2.5;
        const x = 150 + Math.cos(a) * r;
        const y = 150 + Math.sin(a) * r;
        const radius = 12 - t * 5;

        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fillStyle = i === 0 ? color : new THREE.Color(color).multiplyScalar(0.8).getStyle?.() || color;
        ctx.fill();
      }

      // Player icon
      ctx.font = '40px serif';
      ctx.textAlign = 'center';
      ctx.shadowBlur = 0;
      ctx.fillText(GameState.playerIcon || '🟦', 150, 280);

      animFrame = requestAnimationFrame(draw);
    };
    draw();

    // Clean up when leaving customize screen
    document.getElementById('btn-back-customize')?.addEventListener('click', () => {
      cancelAnimationFrame(animFrame);
    }, { once: true });
    document.getElementById('btn-save-customize')?.addEventListener('click', () => {
      cancelAnimationFrame(animFrame);
    }, { once: true });
  }
}

// ─── BOOTSTRAP ───
const game = new Game();
game.init();

// Global safety net: if anything throws anywhere (a browser quirk we
// didn't catch in testing, a bad interaction, etc.) show it on screen
// instead of leaving the page silently stuck — and log full detail to
// the console so it can be diagnosed from a screenshot or bug report.
function showFatalError(err) {
  console.error('[LetterSnake3D] Unhandled error:', err);
  let banner = document.getElementById('ls3d-fatal-error');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'ls3d-fatal-error';
    banner.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);'
      + 'background:#dc2626;color:#fff;padding:12px 20px;border-radius:10px;'
      + 'font:600 13px/1.4 system-ui,sans-serif;z-index:99999;max-width:92vw;'
      + 'box-shadow:0 4px 20px rgba(0,0,0,0.4);text-align:center;';
    document.body.appendChild(banner);
  }
  const msg = (err && (err.message || err.reason?.message || String(err))) || 'Unknown error';
  banner.textContent = `⚠ Something went wrong: ${msg} — try reloading the page.`;
}
window.addEventListener('error', e => showFatalError(e.error || e.message));
window.addEventListener('unhandledrejection', e => showFatalError(e.reason));

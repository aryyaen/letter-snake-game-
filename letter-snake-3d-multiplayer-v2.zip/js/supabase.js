/* ============================================
   supabase.js — Leaderboard + multiplayer storage
   ============================================ */
const Database = (() => {
  let client = null;
  let started = false;
  let initError = null;
  const local = { lobbies: new Map(), members: new Map() };

  function configured() {
    const c = window.SUPABASE_CONFIG || {};
    return Boolean(
      window.supabase && c.url && c.anonKey &&
      !c.url.includes('YOUR_SUPABASE') &&
      !c.anonKey.includes('YOUR_SUPABASE')
    );
  }

  function setupError() {
    return initError ||
      'Online multiplayer is unavailable. Check the Supabase URL/key, enable Anonymous sign-ins, and run supabase/schema.sql.';
  }

  const withTimeout = (promise, ms = 10000) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error('request timed out')), ms))
  ]);

  async function init(force = false) {
    if (started && !force) return client;
    started = true;
    if (!configured()) return null;
    try {
      const { url, anonKey } = window.SUPABASE_CONFIG;
      client = client || window.supabase.createClient(url, anonKey, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false }
      });
      const { data: { session }, error: sessionError } = await withTimeout(client.auth.getSession());
      if (sessionError) throw sessionError;
      if (!session) {
        const { error } = await withTimeout(client.auth.signInAnonymously());
        if (error) throw error;
      }
      initError = null;
      return client;
    } catch (error) {
      initError = `Supabase connection/authentication failed: ${error?.message || error}`;
      console.error(initError);
      client = null;
      if (!force) {
        await new Promise(resolve => setTimeout(resolve, 500));
        return init(true);
      }
      return null;
    }
  }

  async function diagnostics() {
    const db = await init();
    return { configured: configured(), connected: Boolean(db), error: db ? null : setupError() };
  }

  function cleanUsername(value) {
    return String(value || 'Player').replace(/[^a-zA-Z0-9 _-]/g, '').trim().slice(0, 16) || 'Player';
  }

  async function submitScore(gameState) {
    const db = await init();
    if (!db) return { saved: false, reason: configured() ? setupError() : 'not-configured' };
    const payload = {
      username: cleanUsername(gameState.username),
      player_icon: String(gameState.playerIcon || '🟦').slice(0, 8),
      score: Math.min(Math.max(Math.floor(Number(gameState.score) || 0), 0), 1000000),
      letters_collected: Math.min(Math.max(Math.floor(Number(gameState.totalLetters) || 0), 0), 100000),
      players_eaten: Math.min(Math.max(Math.floor(Number(gameState.playersEaten) || 0), 0), 10000),
      survival_seconds: Math.min(Math.max(Math.floor(Number(gameState.survivalTime) || 0), 0), 86400),
      game_mode: ['classic', 'battle', 'letter', 'rush'].includes(gameState.mode) ? gameState.mode : 'classic'
    };
    const { error } = await db.from('leaderboard_scores').insert(payload);
    if (error) { console.error('Score submission failed:', error.message); return { saved: false, reason: error.message }; }
    return { saved: true };
  }

  async function getLeaderboard(limit = 20) {
    const db = await init();
    if (!db) return { data: [], reason: configured() ? setupError() : 'not-configured' };
    const { data, error } = await db.from('leaderboard_scores').select('username, player_icon, score, game_mode, created_at').order('score', { ascending: false }).order('created_at', { ascending: true }).limit(Math.min(Math.max(limit, 1), 50));
    if (error) { console.error('Leaderboard fetch failed:', error.message); return { data: [], reason: error.message }; }
    return { data, reason: null };
  }

  function makeMember(lobby, input, leader = false) {
    return {
      lobby_id: lobby.id,
      player_id: crypto.randomUUID(),
      username: cleanUsername(input.username),
      player_icon: String(input.player_icon || '🟦').slice(0, 8),
      ready: leader,
      is_leader: leader,
      last_seen: new Date().toISOString()
    };
  }

  function localCreate(input) {
    const lobby = { id: `local-${crypto.randomUUID()}`, code: input.code, team_name: input.team_name, max_players: input.max_players, status: 'open' };
    const member = makeMember(lobby, input, true);
    local.lobbies.set(lobby.id, lobby);
    local.members.set(lobby.id, [member]);
    return { lobby, member, demo: true };
  }

  // All lobby writes go through server-side functions (see supabase/schema.sql).
  async function rpc(db, name, args) {
    const { data, error } = await withTimeout(db.rpc(name, args));
    if (error) return { error: error.message, code: error.code };
    return data || {};
  }

  async function createTeam(input) {
    const db = await init();
    if (!db) {
      if (!configured()) return localCreate(input);
      return { error: setupError(), reason: 'backend-unavailable' };
    }
    let res;
    try {
      res = await rpc(db, 'create_team', {
        p_team_name: input.team_name,
        p_max_players: input.max_players,
        p_username: cleanUsername(input.username),
        p_icon: String(input.player_icon || '🟦').slice(0, 8)
      });
    } catch (e) { return { error: `Could not create team: ${e.message}`, reason: 'database' }; }
    if (res.error) return { error: res.reason ? res.error : `Could not create team: ${res.error}. Make sure supabase/schema.sql (v2) was run.`, reason: res.reason || 'database' };
    return { lobby: res.lobby, member: res.member };
  }

  async function joinTeam(input) {
    const db = await init();
    if (!db) {
      if (!configured()) return { error: 'This is a local demo lobby. Configure Supabase URL/key for online teams.', reason: 'not-configured' };
      return { error: setupError(), reason: 'backend-unavailable' };
    }
    let res;
    try {
      res = await rpc(db, 'join_team', {
        p_code: String(input.code || '').trim().toUpperCase(),
        p_username: cleanUsername(input.username),
        p_icon: String(input.player_icon || '🟦').slice(0, 8)
      });
    } catch (e) { return { error: `Could not join team: ${e.message}`, reason: 'database' }; }
    if (res.error) return { error: res.reason ? res.error : `Could not join team: ${res.error}. Make sure supabase/schema.sql (v2) was run.`, reason: res.reason || 'database' };
    return { lobby: res.lobby, member: res.member, members: res.members || [] };
  }

  async function getTeamMembers(id) {
    const db = await init();
    if (!db) return { data: local.members.get(id) || [], error: configured() ? setupError() : null };
    const { data, error } = await db.from('team_members').select('*').eq('lobby_id', id).order('created_at');
    return { data: data || [], error: error?.message };
  }

  async function setTeamReady(lobbyId, playerId, ready) {
    const db = await init();
    if (!db) { const arr = local.members.get(lobbyId) || []; local.members.set(lobbyId, arr.map(m => m.player_id === playerId ? { ...m, ready } : m)); return { ok: true }; }
    const res = await rpc(db, 'set_ready', { p_lobby: lobbyId, p_ready: Boolean(ready) });
    return { ok: Boolean(res.ok), error: res.error };
  }

  async function startTeam(lobbyId, playerId) {
    const db = await init();
    if (!db) { const lobby = local.lobbies.get(lobbyId); const members = local.members.get(lobbyId) || []; if (!members.find(m => m.player_id === playerId)?.is_leader) return { error: 'Only the team leader can start.' }; if (members.length < 2 || !members.every(m => m.ready)) return { error: 'At least two ready players are required.' }; lobby.status = 'started'; return { lobby }; }
    const res = await rpc(db, 'start_team', { p_lobby: lobbyId });
    return res.error ? { error: res.error } : { lobby: res.lobby };
  }

  async function touchTeamMember(lobbyId) { const db = await init(); if (db) { try { await db.rpc('touch_member', { p_lobby: lobbyId }); } catch (_) { /* heartbeat is best-effort */ } } }
  async function leaveTeam(lobbyId, playerId) {
    const db = await init();
    if (!db) { local.members.set(lobbyId, (local.members.get(lobbyId) || []).filter(m => m.player_id !== playerId)); return; }
    try { await db.rpc('leave_team', { p_lobby: lobbyId }); } catch (_) { /* nothing else to do */ }
  }
  function subscribeTeam(id, handler) { if (!client) return null; const ch = client.channel(`team-${id}`).on('postgres_changes', { event: '*', schema: 'public', table: 'team_members', filter: `lobby_id=eq.${id}` }, () => handler({ event: 'member-change' })).on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'team_lobbies', filter: `id=eq.${id}` }, payload => handler({ event: payload.new.status === 'started' ? 'match-started' : 'lobby', payload: payload.new })).on('broadcast', { event: 'state' }, payload => handler({ event: 'state', payload: payload.payload })).subscribe(); return ch; }
  function broadcastTeam(channel, event, payload) { channel?.send({ type: 'broadcast', event, payload }); }
  function removeChannel(channel) { if (client && channel) client.removeChannel(channel); }
  return { init, configured, diagnostics, submitScore, getLeaderboard, createTeam, joinTeam, getTeamMembers, setTeamReady, startTeam, touchTeamMember, leaveTeam, subscribeTeam, broadcastTeam, removeChannel };
})();

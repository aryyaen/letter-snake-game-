/* ============================================
   collectibles.js — Letters, numbers, pickups
   ============================================ */

class CollectibleManager {
  constructor(scene, particles) {
    this.scene = scene;
    this.particles = particles;
    this.items = [];
    this.maxItems = 80;
    this.arenaSize = 95;
    this.spawnTimer = 0;
    this.spawnInterval = 1.5;
    this.specialEventActive = false;
    this.specialEventTimer = 0;
  }

  createLetterMesh(char, color, isGolden = false) {
    const canvas = document.createElement('canvas');
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext('2d');

    // Background bubble
    const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 56);
    if (isGolden) {
      grad.addColorStop(0, 'rgba(255,220,50,0.9)');
      grad.addColorStop(1, 'rgba(200,150,0,0.7)');
    } else {
      const rgb = Utils.hexToRgb(color);
      grad.addColorStop(0, `rgba(${Math.floor(rgb.r*255)},${Math.floor(rgb.g*255)},${Math.floor(rgb.b*255)},0.85)`);
      grad.addColorStop(1, `rgba(${Math.floor(rgb.r*100)},${Math.floor(rgb.g*100)},${Math.floor(rgb.b*100)},0.6)`);
    }

    ctx.beginPath();
    ctx.arc(64, 64, 56, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    // Border glow
    ctx.strokeStyle = isGolden ? '#FFD700' : color;
    ctx.lineWidth = 4;
    ctx.shadowColor = isGolden ? '#FFD700' : color;
    ctx.shadowBlur = 12;
    ctx.stroke();

    // Text
    ctx.font = 'bold 60px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowBlur = 8;
    ctx.fillStyle = '#ffffff';
    ctx.fillText(char, 64, 66);

    const texture = new THREE.CanvasTexture(canvas);
    const mat = new THREE.SpriteMaterial({
      map: texture,
      transparent: true,
      depthTest: false,
    });
    const sprite = new THREE.Sprite(mat);
    return sprite;
  }

  spawnCollectible(forceType = null) {
    if (this.items.length >= this.maxItems) return;

    const a = this.arenaSize;
    const pos = new THREE.Vector3(
      Utils.rand(-a, a),
      0,
      Utils.rand(-a, a),
    );

    // Determine type
    const roll = Math.random();
    let type, char, value, color, isGolden = false, isSpecial = false;

    if (forceType === 'golden' || (Math.random() < 0.03)) {
      // Golden letter — rare, fixed high value (see POINT_VALUES)
      type = 'golden';
      char = Utils.randChoice(LETTERS);
      value = POINT_VALUES.GOLDEN_LETTER;
      color = '#FFD700';
      isGolden = true;
    } else if (roll < 0.5) {
      // Letter — fixed rarity tiers so the point table stays accurate
      type = 'letter';
      char = Utils.randChoice(LETTERS);
      const tierRoll = Math.random();
      if (tierRoll < 0.6) { value = POINT_VALUES.LETTER_COMMON; color = '#22c55e'; }
      else if (tierRoll < 0.9) { value = POINT_VALUES.LETTER_UNCOMMON; color = '#06b6d4'; }
      else { value = POINT_VALUES.LETTER_RARE; color = '#8b5cf6'; }
    } else if (roll < 0.85) {
      // Number — value equals its own face value, always
      type = 'number';
      char = Utils.randChoice(NUMBERS).toString();
      value = parseInt(char);
      color = '#f59e0b';
    } else {
      // Special collectible — fixed values (see POINT_VALUES.SPECIALS)
      type = 'special';
      const specials = [
        { char: '⭐', value: POINT_VALUES.SPECIALS['⭐'], color: '#FFD700' },
        { char: '💎', value: POINT_VALUES.SPECIALS['💎'], color: '#67e8f9' },
        { char: '🔥', value: POINT_VALUES.SPECIALS['🔥'], color: '#f97316' },
        { char: '⚡', value: POINT_VALUES.SPECIALS['⚡'], color: '#fbbf24' },
      ];
      const s = Utils.randChoice(specials);
      char = s.char; value = s.value; color = s.color;
      isSpecial = true;
    }

    // For Letter Hunt mode, override with target letters
    if (GameState.mode === 'letter' && GameState.wordTarget.length > 0) {
      const needed = GameState.wordTarget.filter((l, i) => !GameState.wordCollected[i]);
      if (needed.length > 0 && Math.random() < 0.4) {
        char = Utils.randChoice(needed);
        type = 'letter';
        value = POINT_VALUES.LETTER_UNCOMMON * 2; // target letters are worth double
        color = '#22c55e';
      }
    }

    const sprite = this.createLetterMesh(char, color, isGolden);
    sprite.position.copy(pos);
    sprite.position.y = 1.5 + Utils.rand(0, 0.5);
    sprite.scale.set(isGolden ? 3 : isSpecial ? 2.5 : 2, isGolden ? 3 : isSpecial ? 2.5 : 2, 1);
    this.scene.add(sprite);

    const item = {
      sprite,
      type,
      char,
      value,
      color,
      isGolden,
      isSpecial,
      position: pos,
      floatOffset: Math.random() * Math.PI * 2,
      floatSpeed: 1.5 + Math.random() * 0.5,
      rotSpeed: (Math.random() - 0.5) * 1.5,
      baseY: sprite.position.y,
      collected: false,
      age: 0,
      lifetime: Utils.rand(15, 40),
    };
    this.items.push(item);
    return item;
  }

  spawnBatch(count = 10) {
    for (let i = 0; i < count; i++) {
      this.spawnCollectible();
    }
  }

  // Number storm event
  triggerNumberStorm() {
    for (let i = 0; i < 30; i++) {
      setTimeout(() => this.spawnCollectible(), i * 100);
    }
    this.specialEventActive = true;
    this.specialEventTimer = 15;
    UI.showNotification('⚡ NUMBER STORM! Double value for 15s!', 'special');
    UI.showEvent('⚡ NUMBER STORM!');
    AudioEngine.SFX.specialEvent();
  }

  triggerGoldenLetter() {
    for (let i = 0; i < 5; i++) {
      this.spawnCollectible('golden');
    }
    UI.showNotification('✨ GOLDEN LETTERS appeared!', 'special');
    UI.showEvent('✨ GOLDEN LETTER!');
    AudioEngine.SFX.specialEvent();
  }

  collect(item, snake) {
    if (item.collected) return 0;
    item.collected = true;

    let val = item.value;
    if (this.specialEventActive) val *= 2; // Double value event
    if (GameState.multiplier > 1) val = Math.floor(val * GameState.multiplier);

    // Particles
    this.particles.burst(item.sprite.position, {
      count: item.isGolden ? 20 : item.isSpecial ? 14 : 8,
      color: parseInt(item.color.replace('#', '0x')),
      speed: item.isGolden ? 6 : 4,
      life: item.isGolden ? 1.5 : 0.8,
    });

    // Floating score text
    this.particles.floatingText(item.sprite.position, `+${val}`, item.color);

    // Remove sprite
    this.scene.remove(item.sprite);
    item.sprite.material.dispose();

    // Handle letter hunt mode
    if (GameState.mode === 'letter' && item.type === 'letter') {
      const idx = GameState.wordTarget.findIndex((l, i) => l === item.char && !GameState.wordCollected[i]);
      if (idx !== -1) {
        GameState.wordCollected[idx] = true;
        UI.updateWordDisplay();
        if (GameState.wordCollected.every(Boolean)) {
          UI.showNotification(`🎉 WORD COMPLETE: ${GameState.wordTarget.join('')}! +${POINT_VALUES.WORD_COMPLETE_BONUS}`, 'special');
          val += POINT_VALUES.WORD_COMPLETE_BONUS;
          GameState.wordTarget = WORD_LIST[Utils.randInt(0, WORD_LIST.length - 1)].split('');
          GameState.wordCollected = new Array(GameState.wordTarget.length).fill(false);
          UI.initWordDisplay();
          AudioEngine.SFX.levelUp();
        }
      }
    }

    // Update the collecting snake's own score (real for every snake, AI included —
    // this is what the in-game leaderboard sorts by).
    snake.score += val;

    // The HUD score / stats only ever reflect the human player's own actions —
    // previously this updated for AI pickups too, inflating the displayed score.
    if (snake.isPlayer) {
      GameState.score += val;
      GameState.totalLetters++;
      GameState.lettersCollected.push(item.char);
      if (GameState.lettersCollected.length > 8) GameState.lettersCollected.shift();
    }

    // Sound
    if (item.isGolden) {
      AudioEngine.SFX.levelUp();
    } else if (item.type === 'number') {
      AudioEngine.SFX.collectNumber();
    } else {
      AudioEngine.SFX.collect();
    }

    // Grow snake
    const growAmount = Math.max(1, Math.floor(val / 5));
    snake.grow(growAmount);

    return val;
  }

  update(dt) {
    this.spawnTimer += dt;
    if (this.spawnTimer >= this.spawnInterval) {
      this.spawnTimer = 0;
      this.spawnCollectible();
    }

    // Special event timer
    if (this.specialEventActive) {
      this.specialEventTimer -= dt;
      if (this.specialEventTimer <= 0) {
        this.specialEventActive = false;
      }
    }

    // Random events
    if (Math.random() < 0.0008) {
      const roll = Math.random();
      if (roll < 0.4) this.triggerGoldenLetter();
      else if (roll < 0.8) this.triggerNumberStorm();
    }

    // Animate and cull expired items
    const time = performance.now() * 0.001;
    for (let i = this.items.length - 1; i >= 0; i--) {
      const item = this.items[i];
      if (item.collected) {
        this.items.splice(i, 1);
        continue;
      }

      item.age += dt;
      if (item.age >= item.lifetime) {
        this.scene.remove(item.sprite);
        item.sprite.material.dispose();
        this.items.splice(i, 1);
        continue;
      }

      // Float animation
      item.sprite.position.y = item.baseY + Math.sin(time * item.floatSpeed + item.floatOffset) * 0.5;

      // Pulse golden items
      if (item.isGolden) {
        const pulse = 1 + Math.sin(time * 3) * 0.15;
        item.sprite.scale.set(3 * pulse, 3 * pulse, 1);
        item.sprite.material.opacity = 0.8 + Math.sin(time * 5) * 0.2;
      }

      // Fade near-expiry
      if (item.age > item.lifetime - 3) {
        const fadeT = 1 - (item.lifetime - item.age) / 3;
        item.sprite.material.opacity = 1 - fadeT;
      }
    }
  }

  getItems() { return this.items; }

  dispose() {
    this.items.forEach(item => {
      this.scene.remove(item.sprite);
      item.sprite.material.dispose();
    });
    this.items = [];
  }
}
